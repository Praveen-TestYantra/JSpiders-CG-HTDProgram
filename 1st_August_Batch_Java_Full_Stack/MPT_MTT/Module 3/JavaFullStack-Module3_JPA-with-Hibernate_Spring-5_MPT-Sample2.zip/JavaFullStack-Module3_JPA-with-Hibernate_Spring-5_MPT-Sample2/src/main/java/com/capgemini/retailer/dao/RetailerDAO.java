package com.capgemini.retailer.dao;

import com.capgemini.retailer.beans.RetailerBean;

public interface RetailerDAO {
	public boolean addRetailer(RetailerBean retailer);
	public RetailerBean login(String email, String password);
	public boolean updatePassword(int id, String password);
}
