package com.capgemini.retailer.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.capgemini.retailer.beans.ProductBean;
import com.capgemini.retailer.beans.RetailerBean;
import com.capgemini.retailer.dao.ProductsDAO;
import com.capgemini.retailer.dao.RetailerDAO;

@Controller
@RequestMapping("/retail")
public class RetailerController {
	@Autowired
	private RetailerDAO userDao;
	@Autowired
	private ProductsDAO productsDao;
	
	@GetMapping("/home")
	public String home() {
		return "home";
	}
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@PostMapping("/login")
	public String login(String email, String password, HttpServletRequest request) {
		RetailerBean retailer = userDao.login(email, password);
		if(retailer!=null) {
			request.getSession().setAttribute("retailer", retailer);
			return "home";
		}
		return "login";
	}
	@GetMapping("/search")
	public String search(@RequestParam("id")int productId, ModelMap map) {
		map.addAttribute("product", productsDao.searchProduct(productId));
		return "search";
	}
	@GetMapping("/update-password")
	public String updatePassword() {
		return "update-password";
	}
	@PostMapping("/update-password")
	public String updatePassword(String password, 
			@SessionAttribute(name = "retailer", required = false)RetailerBean retailer) {
		userDao.updatePassword(retailer.getId(), password);
		retailer.setPassword(password);
		return "home";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@PostMapping("/register")
	public String register(RetailerBean retailer) {
		userDao.addRetailer(retailer);
		return "login";
	}
	@GetMapping("/orders")
	public String orders(ModelMap map,
			@SessionAttribute(name = "retailer", required = false) RetailerBean retailer) {
		List<ProductBean> products = productsDao.orders(retailer.getId());
		double amount = productsDao.payableAmount(retailer.getId());
		map.addAttribute("amount", amount);
		map.addAttribute("orders", products);
		return "orders";
	}
	@GetMapping("/order")
	public String order(ModelMap map, @RequestParam("product-id") int productId,
			@SessionAttribute(name = "retailer", required = false) RetailerBean retailer) {
		productsDao.orderProduct(retailer.getId(), productId);
		return "home";
	}
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:./login";
	}
}
