package com.capgemini.retailer.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Component;

import com.capgemini.retailer.beans.ProductBean;
import com.capgemini.retailer.beans.RetailerBean;

@Component
public class ProductDAOHibernateImpl implements ProductsDAO {
	@PersistenceUnit
	private EntityManagerFactory factory;

	@Override
	public boolean addProduct(ProductBean product) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(product);
		transaction.commit();
		return true;
	}

	@Override
	public ProductBean searchProduct(int id) {
		return factory.createEntityManager().find(ProductBean.class, id);
	}

	@Override
	public double payableAmount(int id) {
		RetailerBean retailer = factory.createEntityManager().find(RetailerBean.class, id);
		double amount = 0;
		for (ProductBean product : retailer.getProducts()) {
			amount += product.getPrice();
		}
		return amount;
	}

	@Override
	public List<ProductBean> orders(int id) {
		EntityManager manager = factory.createEntityManager();
		return manager.find(RetailerBean.class, id).getProducts();
	}

	@Override
	public boolean orderProduct(int retailerId, int productId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		RetailerBean retailer = manager.find(RetailerBean.class, retailerId);
		ProductBean product = manager.find(ProductBean.class, productId);
		if(retailer.getProducts() == null) {
			retailer.setProducts(Arrays.asList(product));
		}else {
			retailer.getProducts().add(product);
		}
		transaction.commit();
		return true;
	}
}
