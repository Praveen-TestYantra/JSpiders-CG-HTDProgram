package com.capgemini.retailer.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.capgemini.retailer.beans.RetailerBean;

@Component
public class RetailerDAOHibernateImpl implements RetailerDAO {

	@PersistenceUnit
	private EntityManagerFactory factory;
	
	@Override
	public boolean addRetailer(RetailerBean retailer) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(retailer);
		transaction.commit();
		return true;
	}

	@Override
	public RetailerBean login(String email, String password) {
		String jpql = "From RetailerBean where email=:email and password=:password";
		EntityManager manager = factory.createEntityManager();
		Query query = manager.createQuery(jpql);
		query.setParameter("email", email);
		query.setParameter("password", password);
		return (RetailerBean)query.getSingleResult();
	}

	@Override
	public boolean updatePassword(int id, String password) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		RetailerBean retailer = manager.find(RetailerBean.class, id);
		retailer.setPassword(password);
		manager.persist(retailer);
		transaction.commit();
		return true;
	}

}
