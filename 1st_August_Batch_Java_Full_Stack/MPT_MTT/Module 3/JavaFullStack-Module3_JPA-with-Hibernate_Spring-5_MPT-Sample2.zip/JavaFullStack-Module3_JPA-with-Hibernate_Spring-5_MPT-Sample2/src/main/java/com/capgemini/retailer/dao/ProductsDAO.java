package com.capgemini.retailer.dao;

import java.util.List;

import com.capgemini.retailer.beans.ProductBean;

public interface ProductsDAO {
	public boolean addProduct(ProductBean product);
	public ProductBean searchProduct(int id);
	public double payableAmount(int id);
	public List<ProductBean> orders(int id);
	public boolean orderProduct(int retailerId, int productId);
}
