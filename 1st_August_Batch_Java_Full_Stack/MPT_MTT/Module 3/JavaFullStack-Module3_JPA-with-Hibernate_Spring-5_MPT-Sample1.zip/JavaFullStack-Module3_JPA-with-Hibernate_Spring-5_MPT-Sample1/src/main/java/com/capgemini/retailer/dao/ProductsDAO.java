package com.capgemini.retailer.dao;

import java.util.List;

import com.capgemini.retailer.dto.Product;

public interface ProductsDAO {
	public boolean addProduct(Product product);
	public Product searchProduct(int id);
	public double payableAmount(int id);
	public List<Product> orders(int id);
	public boolean orderProduct(int retailerId, int productId);
}
