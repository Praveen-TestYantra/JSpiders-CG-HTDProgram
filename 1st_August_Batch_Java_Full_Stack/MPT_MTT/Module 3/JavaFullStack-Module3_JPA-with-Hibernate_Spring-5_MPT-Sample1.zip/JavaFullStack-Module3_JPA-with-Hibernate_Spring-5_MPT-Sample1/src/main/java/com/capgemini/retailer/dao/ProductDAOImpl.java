package com.capgemini.retailer.dao;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Component;

import com.capgemini.retailer.dto.Product;
import com.capgemini.retailer.dto.Retailer;

@Component
public class ProductDAOImpl implements ProductsDAO {
	@PersistenceUnit
	private EntityManagerFactory factory;

	@Override
	public boolean addProduct(Product product) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(product);
		transaction.commit();
		return true;
	}

	@Override
	public Product searchProduct(int id) {
		return factory.createEntityManager().find(Product.class, id);
	}

	@Override
	public double payableAmount(int id) {
		Retailer retailer = factory.createEntityManager().find(Retailer.class, id);
		double amount = 0;
		for (Product product : retailer.getProducts()) {
			amount += product.getPrice();
		}
		return amount;
	}

	@Override
	public List<Product> orders(int id) {
		return factory.createEntityManager().find(Retailer.class, id).getProducts();
	}

	@Override
	public boolean orderProduct(int retailerId, int productId) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Retailer retailer = manager.find(Retailer.class, retailerId);
		Product product = manager.find(Product.class, productId);
		if(retailer.getProducts() == null) {
			retailer.setProducts(Arrays.asList(product));
		}else {
			retailer.getProducts().add(product);
		}
		transaction.commit();
		return true;
	}
}
