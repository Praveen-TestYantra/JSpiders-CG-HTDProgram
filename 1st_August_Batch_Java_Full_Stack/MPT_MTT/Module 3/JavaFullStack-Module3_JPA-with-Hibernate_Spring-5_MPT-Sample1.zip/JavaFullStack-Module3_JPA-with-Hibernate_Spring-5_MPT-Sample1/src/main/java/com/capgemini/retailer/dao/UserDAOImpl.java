package com.capgemini.retailer.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import com.capgemini.retailer.dto.Retailer;

@Component
public class UserDAOImpl implements UserDAO {

	@PersistenceUnit
	private EntityManagerFactory factory;
	
	@Override
	public boolean addUser(Retailer retailer) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(retailer);
		transaction.commit();
		return true;
	}

	@Override
	public Retailer login(String email, String password) {
		String jpql = "From Retailer where email=:email and password=:password";
		EntityManager manager = factory.createEntityManager();
		Query query = manager.createQuery(jpql);
		query.setParameter("email", email);
		query.setParameter("password", password);
		return (Retailer)query.getSingleResult();
	}

	@Override
	public boolean updatePassword(int id, String password) {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Retailer retailer = manager.find(Retailer.class, id);
		retailer.setPassword(password);
		manager.persist(retailer);
		transaction.commit();
		return true;
	}

}
