package com.capgemini.retailer.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.capgemini.retailer.dao.ProductsDAO;
import com.capgemini.retailer.dao.UserDAO;
import com.capgemini.retailer.dto.Product;
import com.capgemini.retailer.dto.Retailer;

@Controller
@RequestMapping("/retail")
public class RetailerController {
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private ProductsDAO productsDAO;
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	@PostMapping("/login")
	public String login(String email, String password, HttpServletRequest request) {
		Retailer retailer = userDAO.login(email, password);
		if(retailer!=null) {
			request.getSession().setAttribute("retailer", retailer);
			return "home";
		}
		return "login";
	}
	@GetMapping("/search")
	public String search(@RequestParam("id")int productId, ModelMap map) {
		map.addAttribute("product", productsDAO.searchProduct(productId));
		return "home";
	}
	@GetMapping("/update-password")
	public String updatePassword() {
		return "update-password";
	}
	@PostMapping("/update-password")
	public String updatePassword(String password, 
			@SessionAttribute(name = "retailer", required = false)Retailer retailer) {
		userDAO.updatePassword(retailer.getId(), password);
		retailer.setPassword(password);
		return "home";
	}
	@GetMapping("/register")
	public String register() {
		return "register";
	}
	@PostMapping("/register")
	public String register(Retailer retailer) {
		userDAO.addUser(retailer);
		return "login";
	}
	@GetMapping("/orders")
	public String orders(ModelMap map,
			@SessionAttribute(name = "retailer", required = false) Retailer retailer) {
		List<Product> products = productsDAO.orders(retailer.getId());
		double amount = productsDAO.payableAmount(retailer.getId());
		map.addAttribute("amount", amount);
		map.addAttribute("orders", products);
		return "home";
	}
	@GetMapping("/order")
	public String order(ModelMap map, @RequestParam("product-id") int productId,
			@SessionAttribute(name = "retailer", required = false) Retailer retailer) {
		productsDAO.orderProduct(retailer.getId(), productId);
		return "home";
	}
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:./login";
	}
}
