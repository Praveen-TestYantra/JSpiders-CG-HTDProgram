package com.capgemini.retailer.dao;

import com.capgemini.retailer.dto.Retailer;

public interface UserDAO {
	public boolean addUser(Retailer retailer);
	public Retailer login(String email, String password);
	public boolean updatePassword(int id, String password);
}
