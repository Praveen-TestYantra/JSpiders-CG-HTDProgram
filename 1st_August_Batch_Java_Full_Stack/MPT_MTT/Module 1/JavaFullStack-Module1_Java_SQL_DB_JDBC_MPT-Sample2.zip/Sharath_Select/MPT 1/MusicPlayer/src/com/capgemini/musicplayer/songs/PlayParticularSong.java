package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class PlayParticularSong {

	void playParticularSong() {

		try(Scanner scanner = new Scanner(System.in);
				FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select Song_Title from MusicFiles where Song_Title = ?";

			Class.forName(properties.getProperty("driver_name"));

			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)){
				System.out.println("Enter the song to be played");
				String song_title = scanner.next(); 
				preparedStatement.setString(1, song_title);
				try(ResultSet resultSet = preparedStatement.executeQuery()) {

					while(resultSet.next()) {
						System.out.println("Playing : "+ resultSet.getString("Song_Title"));

						try {
							Thread.sleep(4000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}

				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
