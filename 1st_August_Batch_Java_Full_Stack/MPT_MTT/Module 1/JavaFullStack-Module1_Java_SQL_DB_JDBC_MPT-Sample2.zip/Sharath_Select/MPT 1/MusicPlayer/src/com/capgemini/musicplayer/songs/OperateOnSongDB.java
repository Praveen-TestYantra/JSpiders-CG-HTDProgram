package com.capgemini.musicplayer.songs;

import java.util.Scanner;

public class OperateOnSongDB {

	void songDB() {
		
		System.out.println("Press A to AddSong ");
		System.out.println("Press B to EditSong details ");
		System.out.println("Press C to DeleteSong from DB ");
		try(Scanner scanner = new Scanner(System.in)) {
			char option = scanner.next().charAt(0);
			
			switch(option) {
			case 'A':AddSong addSong = new AddSong();
			addSong.addSongs();
			break;
			case 'B':EditSong editSong = new EditSong();
			editSong.editSong();
			break;
			case 'C': DeleteSong deleteSong = new DeleteSong();
			deleteSong.deleteSong();
			break;
			}
		}
		
	}
}
