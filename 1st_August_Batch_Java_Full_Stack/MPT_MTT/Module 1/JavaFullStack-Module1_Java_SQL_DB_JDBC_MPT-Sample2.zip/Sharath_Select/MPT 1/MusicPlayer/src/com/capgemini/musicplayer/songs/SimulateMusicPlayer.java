package com.capgemini.musicplayer.songs;

import java.util.Scanner;

public class SimulateMusicPlayer {

	public static void main(String[] args) {

		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("Press 1 to play a song");
			System.out.println("Press 2 to search a song");
			System.out.println("Press 3 to show all song");
			System.out.println("Press 4 to operate on songDB");
			System.out.println("Choose your Options");
			int options = scanner.nextInt();

			switch (options) {
			case 1:
				PlaySong playSong = new PlaySong();
				playSong.playSong();
				break;
			case 2:
				SearchSong searchSong = new SearchSong();
				System.out.println("Enter the song to be searched");
				String songTitle = scanner.next();
				searchSong.searchBySong(songTitle);
				break;
			case 3:
				ShowAllSongs allSongs = new ShowAllSongs();
				allSongs.showSongs();
				break;
			case 4:
				OperateOnSongDB onSongDB = new OperateOnSongDB();
				onSongDB.songDB();
				break;
			default:
				System.out.println("Please Choose valid options");
			}
		}
	}

}
