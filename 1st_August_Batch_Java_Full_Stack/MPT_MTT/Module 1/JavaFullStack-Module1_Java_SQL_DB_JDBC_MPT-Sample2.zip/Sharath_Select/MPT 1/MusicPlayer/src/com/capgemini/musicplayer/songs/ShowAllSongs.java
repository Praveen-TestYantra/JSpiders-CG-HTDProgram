package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;


public class ShowAllSongs {

	void showSongs() {

		try(FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();

			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles order by Song_Title";

			Class.forName(properties.getProperty("driver_name"));

			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);
					ResultSet resultSet = preparedStatement.executeQuery()) {
				System.out.println("Song_ID\tSong_Title\tArtist_Name\tAlbum_Name\tSong_Location\tDescription");
				while(resultSet.next()) {
					System.out.print(resultSet.getInt("Song_ID")+"\t");
					System.out.print(resultSet.getString("Song_Title")+"\t");
					System.out.print(resultSet.getString("Artist_Name")+"\t");
					System.out.print(resultSet.getString("Album_Name")+"\t");
					System.out.print(resultSet.getString("Song_Location")+"\t");
					System.out.print(resultSet.getString("Description")+"\t");
					System.out.println();
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
