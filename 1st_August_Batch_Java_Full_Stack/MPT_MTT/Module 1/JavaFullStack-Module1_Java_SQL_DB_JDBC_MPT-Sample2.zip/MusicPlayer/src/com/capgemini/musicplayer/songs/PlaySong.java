package com.capgemini.musicplayer.songs;

import java.util.Scanner;

public class PlaySong {

	void playSong() {
		try (Scanner scanner = new Scanner(System.in)) {

			System.out.println("Press A to play all song");
			System.out.println("Press B to play songs randomly");
			System.out.println("Press C to play a particular song");
			char value = scanner.next().charAt(0);

			switch (value) {

			case 'A':
				PlayAllSongs allSongs = new PlayAllSongs();
				allSongs.playAllSongs();
				break;
			case 'B':
				PlayRandomSongs randomSongs = new PlayRandomSongs();
				randomSongs.randomSong();
				break;
			case 'C':
				PlayParticularSong particularSong = new PlayParticularSong();
				particularSong.playParticularSong();
				break;
			default:
				System.out.println("Please Choose valid options");
			}
		}
	}
}
