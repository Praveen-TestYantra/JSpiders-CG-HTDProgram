package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class SearchSong {
	void searchBySong(String songTitle) {
		
		try(FileInputStream stream = new FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			properties.load(stream);
			
			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles where Song_Title = ?";
			
			Class.forName(properties.getProperty("driver_name"));
			
			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				preparedStatement.setString(1, songTitle);
				System.out.println("Title \t Artist \t Album");
				System.out.println("------------------------------------------");
				try(ResultSet resultSet = preparedStatement.executeQuery()) {
					if(resultSet.next()) {
						System.out.print(resultSet.getString("Song_Title")+"\t");
						System.out.print(resultSet.getString("Artist_Name")+" \t");
						System.out.print(resultSet.getString("Album_Name")+" \t");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
