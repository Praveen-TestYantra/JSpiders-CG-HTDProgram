package com.capgemini.musicplayer.songs;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class EditSong {

	void editSong() {
		
		try(Scanner scanner = new Scanner(System.in);
				FileInputStream stream = new  FileInputStream("assessment.properties")) {
			Properties properties = new Properties();
			
			properties.load(stream);
			
			String url = properties.getProperty("url");
			String sql = "Update MusicFiles set Song_Title = ?,Artist_Name = ? where Song_ID= ?";
			
			Class.forName(properties.getProperty("driver_name"));
			
			try(Connection connection = DriverManager.getConnection(url,properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
				
				System.out.println("Enter the Song_ID to be Edited");
				int songId = scanner.nextInt();
			
				System.out.println("Enter the new Song_Title");
				String songTitle = scanner.next();
				
				System.out.println("Enter the new Artist_Name");
				String artistName = scanner.next();
				
				preparedStatement.setString(1, songTitle);
				preparedStatement.setString(2, artistName);
				preparedStatement.setInt(3, songId);
				
				int count = preparedStatement.executeUpdate();
				
				System.out.println(count + " row affected");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}
