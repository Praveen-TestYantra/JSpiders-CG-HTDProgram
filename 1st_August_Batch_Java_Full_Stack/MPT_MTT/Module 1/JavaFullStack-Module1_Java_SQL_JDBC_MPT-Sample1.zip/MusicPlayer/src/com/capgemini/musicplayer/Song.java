package com.capgemini.musicplayer;

public class Song {
	String songTitle;
	String artistName;
	String albumName;
	String songLocation;
	String songDesc;
	@Override
	public String toString() {
		return "Song [songTitle=" + songTitle + ", artistName=" + artistName + ", albumName=" + albumName
				+ ", songLocation=" + songLocation + ", songDesc=" + songDesc + "]";
	}
	
	
	
	
}
