package com.capgemini.musicplayer;

import java.util.Scanner;

public class OperateSong {
	static void operate() {
		Scanner scanner = new Scanner(System.in);
		
		
		System.out.println("Press A to Add Song");
		System.out.println("Press B to Edit an Existing Song");
		System.out.println("Press C to Delete an Existing Song");
		System.out.print("Enter your option:");
		
		
		String option=scanner.next();
		
		switch (option) {
		case "A":
			AddSong.addSong();
			break;
		
		
		case "B": 	
			EditSong.editSong();
			break;
		
		case "C":
			DeleteSong.deleteSong();
			break;
		

		default:
			System.out.println("Invalid Input");
			break;
		}
		
	}

}
