package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class EditSong {
	static void editSong() {
		Scanner scanner = new Scanner(System.in);
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Update MusicFiles " + "Set Song_Title=?," + "Artist_Name=?," + "Album_Name=?, "
					+ "Song_Location=?," + "Description=?" + "where Song_Id=?";

			Class.forName(properties.getProperty("driver_class_name"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				System.out.print("Enter Song Id to be Edited :");
				int songId = scanner.nextInt();
				scanner.nextLine();

				System.out.print("New Song Title: ");
				String songTitle = scanner.nextLine();

				System.out.print("New Artist Name:");
				String artistName = scanner.nextLine();

				System.out.print("New Album Name:");
				String albumName = scanner.nextLine();

				System.out.print("Song Location:");
				String songLocation = scanner.nextLine();

				System.out.print("Song Description:");
				String songDesc = scanner.nextLine();

				preparedStatement.setInt(6, songId);
				preparedStatement.setString(1, songTitle);
				preparedStatement.setString(2, artistName);
				preparedStatement.setString(3, albumName);
				preparedStatement.setString(4, songLocation);
				preparedStatement.setString(5, songDesc);

				int count = preparedStatement.executeUpdate();
				System.out.println(count + " song edited");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
