package com.capgemini.musicplayer;

import java.util.Scanner;

public class MusicPlayerTest {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Welcome to Music Player");
		while (true){
			System.out.println();
			System.out.println("Press 1 to Play a Song");
			System.out.println("Press 2 to Search a Song");
			System.out.println("Press 3 to Show All Songs");
			System.out.println("Press 4 to Operate on Songs Database");
			System.out.println("Press 5 to Exit");
			
			
			System.out.print("Enter your option:");
			int option =scanner.nextInt();

			System.out.println();
			switch (option) {
			case 1: 
				PlaySong.playSong();
				break;

			case 2:
				System.out.print("Enter Song Title: ");
				String songTitle= scanner.next();
				SearchSong.searchSong(songTitle);
				break;

			case 3:
				ShowSongs.showSongs();
				break;

			case 4:
				OperateSong.operate();
				break;
				
			case 5:
				System.exit(0);
				
			default:
				System.out.println("Invalid Input");
				break;
			}
			
		} 
		
	}

}
