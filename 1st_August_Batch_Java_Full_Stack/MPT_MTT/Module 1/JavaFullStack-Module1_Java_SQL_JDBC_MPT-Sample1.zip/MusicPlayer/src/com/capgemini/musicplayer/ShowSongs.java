package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class ShowSongs {
	static void showSongs() {

		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles";

			Class.forName(properties.getProperty("driver_class_name"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {
				System.out.println("Title\tArtist\tAlbum\tLocation\tDescription	");
				System.out.println("---------------------------");
				while (resultSet.next()) {
					System.out.print(resultSet.getString("Song_Title") + "\t");
					System.out.print(resultSet.getString("Artist_Name") + "\t");
					System.out.print(resultSet.getString("Album_Name") + "\t");
					System.out.print(resultSet.getString("Song_Location") + "\t");
					System.out.print(resultSet.getString("Description") + "\t");
					System.out.println();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
