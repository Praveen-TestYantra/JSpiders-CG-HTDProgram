package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;
import java.util.Scanner;

public class AddSong {
	static void addSong() {
		Scanner scanner = new Scanner(System.in);
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Insert into MusicFiles values(?,?,?,?,?,?)";

			Class.forName(properties.getProperty("driver_class_name"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql)) {

				System.out.println("Enter Song Details");
				System.out.println("--------------------");

				System.out.print("Song Id: ");
				int songId = scanner.nextInt();

				System.out.print("Song Title: ");
				String songTitle = scanner.next();

				System.out.print("Artist Name:");
				String artistName = scanner.next();

				System.out.print("Album Name:");
				String albumName = scanner.next();

				System.out.print("Song Location:");
				String songLocation = scanner.next();

				System.out.print("Song Description:");
				String songDesc = scanner.next();

				preparedStatement.setInt(1, songId);
				preparedStatement.setString(2, songTitle);
				preparedStatement.setString(3, artistName);
				preparedStatement.setString(4, albumName);
				preparedStatement.setString(5, songLocation);
				preparedStatement.setString(6, songDesc);

				int count = preparedStatement.executeUpdate();
				System.out.println(count + " song added");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
