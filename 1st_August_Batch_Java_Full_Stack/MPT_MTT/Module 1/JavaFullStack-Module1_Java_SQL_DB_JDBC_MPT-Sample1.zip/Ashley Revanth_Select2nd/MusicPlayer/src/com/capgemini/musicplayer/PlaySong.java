package com.capgemini.musicplayer;

import java.util.Scanner;

public class PlaySong {
	
	 static void playSong() {
		System.out.println("Press A to Play all songs");
		System.out.println("Press B to Play Songs Randomly");
		System.out.println("Press C to Play a Particular Song");
		System.out.print("Enter your option: ");
		
		Scanner scanner = new Scanner(System.in);
		String option=scanner.next();
		 
		switch (option) {
		case "A": 	
			PlayAll.playAll();
			break;
		
		
		case "B": 	
			DisplayShuffledSongs.shuffle();
			break;
		
		case "C":	
			System.out.println();
			System.out.print("Enter Song Title: ");
			String songTitle= scanner.next();
			PlayParticular.playParticular(songTitle);
			break;
		

		default:
			System.out.println("Invalid Input");
			break;
		}
		
		
	}

}
