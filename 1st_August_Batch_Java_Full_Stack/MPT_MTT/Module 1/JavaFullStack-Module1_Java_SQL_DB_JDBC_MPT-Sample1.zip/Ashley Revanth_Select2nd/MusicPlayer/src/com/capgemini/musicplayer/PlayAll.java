package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class PlayAll {
	static void playAll() {
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles Order by Song_Title";

			Class.forName(properties.getProperty("driver_class_name"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {

				while (resultSet.next()) {
					System.out.println("Playing Song " + resultSet.getString("Song_Title"));
					Thread.sleep(1000);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
