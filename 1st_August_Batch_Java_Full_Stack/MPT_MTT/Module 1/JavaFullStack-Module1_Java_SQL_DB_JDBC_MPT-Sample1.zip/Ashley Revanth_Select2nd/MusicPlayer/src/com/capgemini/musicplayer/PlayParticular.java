package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class PlayParticular {
	static void playParticular(String songTitle) {
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles where Song_Title=?";

			Class.forName(properties.getProperty("driver_class_name"));

			try (Connection connection = DriverManager.getConnection(url, properties);
					PreparedStatement preparedStatement = connection.prepareStatement(sql);) {

				preparedStatement.setString(1, songTitle);

				try (ResultSet resultSet = preparedStatement.executeQuery()) {
					if (resultSet.next()) {
						System.out.println("Paying Song " + resultSet.getString("Song_Title"));
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
