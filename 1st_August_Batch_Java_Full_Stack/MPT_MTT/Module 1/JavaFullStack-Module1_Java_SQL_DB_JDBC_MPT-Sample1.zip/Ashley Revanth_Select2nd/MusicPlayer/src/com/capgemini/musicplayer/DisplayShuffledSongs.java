package com.capgemini.musicplayer;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Properties;

public class DisplayShuffledSongs {
	static void shuffle() {
		try (FileInputStream stream = new FileInputStream("jdbc.properties")) {
			Properties properties = new Properties();
			properties.load(stream);

			String url = properties.getProperty("url");
			String sql = "Select * from MusicFiles";

			Class.forName(properties.getProperty("driver_class_name"));

			ArrayList<Song> al = new ArrayList<Song>();

			try (Connection connection = DriverManager.getConnection(url, properties);
					Statement statement = connection.createStatement();
					ResultSet resultSet = statement.executeQuery(sql)) {
				while (resultSet.next()) {
					Song s = new Song();

					s.songTitle = resultSet.getString("Song_Title");
					s.artistName = resultSet.getString("Artist_Name");
					s.albumName = resultSet.getString("Album_Name");
					s.songLocation = resultSet.getString("Song_Location");
					s.songDesc = resultSet.getString("Description");
					al.add(s);

				}
				Collections.shuffle(al);
				for (Song song : al) {

					System.out.println("Playing Song " + song.songTitle);
					Thread.sleep(1000);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
