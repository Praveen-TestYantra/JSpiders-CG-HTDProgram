import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  selectedUser = {
    userName : null,
    email : null,
    phno : null,
    id : null
  };
  constructor(private userService: UserService) {
  }

  selectUser(user) {
    this.selectedUser = user;
  }

  deleteUser(user) {
    this.userService.users.splice(this.userService.users.indexOf(user), 1);
  }

  updateUser(updateUserForm: NgForm) {
    const index = this.userService.users.indexOf(this.selectUser);
    this.userService.users.splice(index, 1, updateUserForm.value);
    updateUserForm.reset();
  }

  ngOnInit() {
  }

}
