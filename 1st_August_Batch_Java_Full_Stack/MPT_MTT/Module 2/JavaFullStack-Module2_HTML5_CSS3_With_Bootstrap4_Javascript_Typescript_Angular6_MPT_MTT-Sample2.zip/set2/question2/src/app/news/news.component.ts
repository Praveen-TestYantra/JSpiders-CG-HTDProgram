import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {


  newss = [];

  constructor(private http: HttpClient) {
    this.searchNews();
  }

  searchNews() {
    this.http.get<any>(`https://newsapi.org/v2/top-headlines?country=in&apiKey=c33ff9edd8b044aa9df9cadfe86ebe53`)
    .subscribe(data => {
      this.newss = data.articles ;
      console.log(this.newss);
    });
  }

  ngOnInit() {
  }

}
