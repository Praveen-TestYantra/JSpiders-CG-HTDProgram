import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taskmanager',
  templateUrl: './taskmanager.component.html',
  styleUrls: ['./taskmanager.component.css']
})
export class TaskmanagerComponent implements OnInit {

  tasks = [];
  constructor() { }

  ngOnInit() {
  }
  addTask(task) {
    this.tasks.push(task);
  }
  delete(task) {
    this.tasks.splice(this.tasks.indexOf(task), 1);
  }

}
