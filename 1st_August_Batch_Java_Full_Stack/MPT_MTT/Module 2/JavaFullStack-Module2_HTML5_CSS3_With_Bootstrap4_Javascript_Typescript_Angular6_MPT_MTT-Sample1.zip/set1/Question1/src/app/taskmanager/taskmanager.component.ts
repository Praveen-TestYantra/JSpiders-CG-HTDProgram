import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-taskmanager',
  templateUrl: './taskmanager.component.html',
  styleUrls: ['./taskmanager.component.css']
})
export class TaskmanagerComponent implements OnInit {
  inputIs = [];
  constructor() { }

  ngOnInit() {
  }
  store(input) {
    if (input !== undefined) {
      this.inputIs.push(input);
    }
  }
  deleteTask(task) {
    const index = this.inputIs.indexOf(task);
    this.inputIs.splice(index, 1);
  }

}
