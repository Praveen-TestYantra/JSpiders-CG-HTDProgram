import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {


  news = [];

  constructor(private http: HttpClient) {
    this.getNews();
  }

  getNews() {
    this.http.get<any>(`https://newsapi.org/v2/top-headlines?country=in&apiKey=823d6bd0923447c3a255fa0bf4daccf4`)
    .subscribe(data => {
      this.news = data.articles ;
      console.log(this.news);
    } );

  }

  ngOnInit() {
  }

}
