import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  selectedUser = {
    userName : null,
    email : null,
    phno : null,
    id : null
  };
  constructor(private userService: UserService) {
    this.userService.getData();
   }

   selectUser(user) {
     this.selectedUser = user;
   }
   callGetData() {
     this.userService.getData();
   }

   updateUser(updateUserForm: NgForm) {
     this.userService.putData(updateUserForm.value).subscribe(resData => {
       console.log(resData);
       updateUserForm.reset();
     }, err => {
       console.log(err);
     });

   }
   deleteUser(user) {
    this.userService.deleteData(user).subscribe(resData => {
      console.log(resData);
      this.userService.getData();
    }, err => {
      console.log(err);
    });
   }

  ngOnInit() {
  }

}
