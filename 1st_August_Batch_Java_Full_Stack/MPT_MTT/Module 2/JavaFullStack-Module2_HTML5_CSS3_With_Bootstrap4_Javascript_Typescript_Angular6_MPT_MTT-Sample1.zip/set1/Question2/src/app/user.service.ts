import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {

    users = [];
  api = 'https://assignments-834f7.firebaseio.com/';
  constructor(private http: HttpClient) { }

  postData(user) {
    return this.http.post(`${this.api}users.json`, user);
  }
  putData(user) {
    return this.http.put(`${this.api}users/${user.id}.json`, user);
  }

  deleteData(user) {
    return this.http.delete(`${this.api}users/${user.id}.json`);
  }
  getData() {
    this.http.get(`${this.api}users.json`).pipe(map(resData => {
      const users = [];
      for (const key in resData) {
        users.push({...resData[key], id: key});
      }
      return users;
    })).subscribe(data => {
      this.users = data;
      console.log(this.users);
    });
  }
}
