import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { AuthResponse } from './auth-response';

@Injectable({
    providedIn : 'root'
})
export class AuthService{

    user = new Subject<AuthResponse>();
    
    constructor(private http : HttpClient){}

    register(userDetails){
        return this.http.post('https://newsapi.org/v2/top-headlines?country=in&apiKey=823d6bd0923447c3a255fa0bf4daccf4',userDetails)
    }
}
