package Actions;

import org.testng.Reporter;

public class BaseTest {
	public void m1() { Reporter.log("@BeforeSuite",true);}
	
	public void m2() {Reporter.log("@BeforeTest",true);}
	
	public void m3() {Reporter.log("@Beforeclass",true);}
	
	

}
	