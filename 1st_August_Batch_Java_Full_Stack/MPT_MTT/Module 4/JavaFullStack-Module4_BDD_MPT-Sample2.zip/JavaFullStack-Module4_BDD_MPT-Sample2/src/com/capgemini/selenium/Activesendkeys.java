package com.capgemini.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Activesendkeys {
	static {
		System.setProperty("webdriver.chrome.driver", "./driver/chromedriver.exe");	
	}
	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.actitime.com/login.do");
		driver.manage().window().maximize();
		// WebElement send=driver.switchTo().activeElement(); 
		
		  driver.findElement(By.id("username")).sendKeys("admin");
		  driver.findElement(By.name("pwd")).sendKeys("manager");
		  driver.findElement(By.linkText("Login")).click();
		  	
		  driver.get("http://demo.actitime.com./TASKS.do");
		  driver.manage().window().maximize();
		  driver.findElement(By.linkText("TASKS")).click();
		  
		  driver.getTitle();
		  driver.manage().window().maximize();
		  driver.findElement(By.className("addNewButton")).click();
		  
		  driver.getTitle();
		  driver.manage().window().maximize();
		  driver.findElement(By.className("createNewTasks")).click();
	}

}
