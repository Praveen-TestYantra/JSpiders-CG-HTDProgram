package com.capgemini.hotelbilling.dao;

public interface FoodItemDAO {

	public void showAllFoodItems();
	public void addItem();
	public void removeItem();
	public void modifyItem();
	public void takeOrderMethod();
	public void viewFinalBill();
}
