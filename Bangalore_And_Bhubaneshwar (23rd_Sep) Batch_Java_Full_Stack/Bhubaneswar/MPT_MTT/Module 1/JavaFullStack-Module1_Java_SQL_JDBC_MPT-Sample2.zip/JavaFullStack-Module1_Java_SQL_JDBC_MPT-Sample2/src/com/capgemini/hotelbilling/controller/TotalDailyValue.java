package com.capgemini.hotelbilling.controller;

import com.capgemini.hotelbilling.dao.FoodItemDAO;
import com.capgemini.hotelbilling.factory.FoodFactory;

public class TotalDailyValue {

	public static void viewFinalBill() {
		FoodItemDAO dao = FoodFactory.getInstance();
		dao.viewFinalBill();
	}
}
