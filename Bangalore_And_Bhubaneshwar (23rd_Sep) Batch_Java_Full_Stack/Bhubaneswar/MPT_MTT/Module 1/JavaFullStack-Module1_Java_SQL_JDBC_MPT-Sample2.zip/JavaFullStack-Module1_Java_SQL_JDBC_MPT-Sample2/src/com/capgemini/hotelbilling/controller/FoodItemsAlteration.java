package com.capgemini.hotelbilling.controller;

import java.util.Scanner;

import com.capgemini.hotelbilling.dao.FoodItemDAO;
import com.capgemini.hotelbilling.factory.FoodFactory;

public class FoodItemsAlteration {

	public static void go() {

		FoodItemDAO dao = FoodFactory.getInstance();

		Scanner sc = new Scanner(System.in);

		System.out.println();
		System.out.println("Press A to add food items");
		System.out.println("Press B to remove food items");
		System.out.println("Press C to modify food items");

		System.out.print("\nYour response : ");

		String response = sc.nextLine();

		switch (response) {
		case "A":

			dao.addItem();
			break;

		case "B":
			dao.removeItem();
			break;

		case "C":
			dao.modifyItem();
			break;

		default:
			break;
		}
	}
}
