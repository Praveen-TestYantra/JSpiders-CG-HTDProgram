package com.capgemini.hotelbilling.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hotelbilling.services.FoodInfoValidation;

public class FoodInfoValidationImpl implements FoodInfoValidation {

	Pattern pat = null;
	Matcher mat = null;
	
	@Override
	public boolean itemCodeValidation(String id) {

		pat = Pattern.compile("\\d+");
		mat = pat.matcher(id);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean foodItemValidation(String name) {

		pat = Pattern.compile("\\w+");
		mat = pat.matcher(name);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean priceValidation(String email) {

		pat = Pattern.compile("\\d+");
		mat = pat.matcher(email);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
}
