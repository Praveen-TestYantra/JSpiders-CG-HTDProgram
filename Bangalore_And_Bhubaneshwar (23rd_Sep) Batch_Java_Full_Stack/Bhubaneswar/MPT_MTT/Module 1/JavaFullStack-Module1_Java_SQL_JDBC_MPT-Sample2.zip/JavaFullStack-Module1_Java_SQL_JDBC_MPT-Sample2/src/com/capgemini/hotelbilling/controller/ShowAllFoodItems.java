package com.capgemini.hotelbilling.controller;

import com.capgemini.hotelbilling.dao.FoodItemDAO;
import com.capgemini.hotelbilling.factory.FoodFactory;


public class ShowAllFoodItems {

	public static void showAllFoodItems() {
		
		FoodItemDAO dao = FoodFactory.getInstance();
		dao.showAllFoodItems();
	}
}
