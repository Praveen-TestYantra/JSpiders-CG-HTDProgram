package com.capgemini.hotelbilling.factory;

import com.capgemini.hotelbilling.dao.FoodItemDAO;
import com.capgemini.hotelbilling.dao.FoodItemDAOJDBCImpl;

public class FoodFactory {
	
	public static FoodItemDAO getDAOImplInstance() {
		FoodItemDAO dao = new FoodItemDAOJDBCImpl();
		return dao;
	}
	
	public static FoodItemDAO getInstance() {

		FoodItemDAO dao = new FoodItemDAOJDBCImpl();
		return dao;
	}

	
}
