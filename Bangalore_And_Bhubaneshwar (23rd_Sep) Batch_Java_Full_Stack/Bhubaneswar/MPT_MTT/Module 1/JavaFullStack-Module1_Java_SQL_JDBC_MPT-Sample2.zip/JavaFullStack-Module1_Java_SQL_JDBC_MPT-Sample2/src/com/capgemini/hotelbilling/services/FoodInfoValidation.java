package com.capgemini.hotelbilling.services;

public interface FoodInfoValidation {
	
	public boolean itemCodeValidation(String id);
	public boolean foodItemValidation(String name);
	public boolean priceValidation(String price);
}
