package com.capgemini.hotelbilling.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotelbilling.bean.FoodItems;
import com.capgemini.hotelbilling.validation.FoodInfoValidationImpl;

public class FoodItemDAOJDBCImpl implements FoodItemDAO {

	FoodItems food;
	FileReader reader = null;
	Properties prop = null;

	static Scanner scanner = new Scanner(System.in);
	public static ArrayList<FoodItems> orderlists = new ArrayList<FoodItems>();
	static ArrayList<Double> finalbill = new ArrayList<Double>();

	FoodInfoValidationImpl uv = new FoodInfoValidationImpl();

	Scanner sc = new Scanner(System.in);

	public FoodItemDAOJDBCImpl() {

		try {
			Class.forName("com.mysql.jdbc.Driver");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showAllFoodItems() {

		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {

			String dbUrl = "jdbc:mysql://localhost:3307/hotel_db?user=root&password=xlr8rox";
			conn = DriverManager.getConnection(dbUrl);

			String query = "select * from hotel_bill";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) {

				System.out.println();
				System.out.println("Item Code : " + rs.getInt(1));
				System.out.println("Food Name : " + rs.getString(2));
				System.out.println("Price	  : " + rs.getString(3));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void addItem() {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver Loaded.");
			System.out.println("--------------------------------------------");

			String dbUrl = "jdbc:mysql://localhost:3307/hotel_db?user=root&password=xlr8rox";
			conn = DriverManager.getConnection(dbUrl);

			System.out.println("Connection is established.");
			System.out.println("--------------------------------------------");

			String query = "INSERT INTO hotel_bill VALUES (?,?,?)";

			pstmt = conn.prepareStatement(query);

			System.out.print("Enter Item Code : ");
			String itemcode = sc.nextLine();

			if (uv.itemCodeValidation(itemcode)) {
				pstmt.setInt(1, Integer.parseInt(itemcode));
			}

			else {
				System.out.println("Invalid Item Code. Try again.");
				System.exit(0);
			}

			System.out.print("Enter Food Name : ");
			String name = sc.nextLine();

			if (uv.foodItemValidation(name)) {
				pstmt.setString(2, name);
			} else {
				System.out.println("Invalid Food Name. Try again.");
				System.exit(0);
			}

			System.out.print("Enter Price : ");
			String price = sc.nextLine();

			if (uv.priceValidation(price)) {
				pstmt.setDouble(3, Double.parseDouble(price));
			} else {
				System.out.println("Invalid Price. Try again.");
				System.exit(0);
			}
			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("\nNew Food item is inserted successfully.");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public void modifyItem() {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver Loaded.");
			System.out.println("--------------------------------------------");

			String dbUrl = "jdbc:mysql://localhost:3307/hotel_db?user=root&password=xlr8rox";

			conn = DriverManager.getConnection(dbUrl);

			System.out.println("Connection is established.");
			System.out.println("--------------------------------------------");

			String query = "UPDATE hotel_bill SET Food_name = ? , price = ? where item_code = ?";

			pstmt = conn.prepareStatement(query);

			System.out.print("Enter Item Code for which the value to be changed : ");

			pstmt.setInt(3, Integer.parseInt(sc.nextLine()));

			System.out.print("Enter the new Food name : ");
			pstmt.setString(1, sc.nextLine());

			System.out.print("Enter the new Value : ");
			pstmt.setDouble(2, Double.parseDouble(sc.nextLine()));

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("\nThe properties of the given food item are changed successfully.");
			}

		} catch (Exception e) {
			System.out.println("Sorry, something went wrong. Try again.");
		}

		finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}

	public void removeItem() {

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {

			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver Loaded.");
			System.out.println("--------------------------------------------");

			String dbUrl = "jdbc:mysql://localhost:3307/hotel_db?user=root&password=xlr8rox";

			conn = DriverManager.getConnection(dbUrl);

			System.out.println("Connection is established.");
			System.out.println("--------------------------------------------");

			String query = "DELETE FROM hotel_bill WHERE item_code = ?";

			pstmt = conn.prepareStatement(query);

			System.out.print("Enter Item code you want to delete: ");
			pstmt.setInt(1, Integer.parseInt(sc.nextLine()));

			int count = pstmt.executeUpdate();

			if (count > 0) {
				System.out.println("\nThe food item is deleted successfully.");
			}

		} catch (Exception e) {
			System.out.println("Something went wrong. Run again.");
			e.printStackTrace();
		}

		finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					System.out.println("Sorry, Something went wrong. Try again.");
					e.printStackTrace();
				}
			}

			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					System.out.println("Sorry, Something went wrong. Try again.");
					e.printStackTrace();
				}
			}

		}
	}

	public static void addFoodItem(int itemCode) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		FoodItems confirmedItem = new FoodItems();

		try {
			Class.forName("com.mysql.jdbc.Driver");

			String dbUrl = "jdbc:mysql://localhost:3307/hotel_db?user=root&password=xlr8rox";
			conn = DriverManager.getConnection(dbUrl);

			String query = "select * from hotel_bill where item_code = ?";

			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1, itemCode);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				confirmedItem.setItemCode(Integer.parseInt(rs.getString(1)));
				confirmedItem.setFoodName(rs.getString(2));
				confirmedItem.setPrice(rs.getDouble(3));

				orderlists.add(confirmedItem);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {

			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void takeOrderMethod() {

		int orderedItemCode = 1;

		while (orderedItemCode != 0) {
			System.out.print("\nEnter the Item codes you want to purchase : ");
			orderedItemCode = scanner.nextInt();
			addFoodItem(orderedItemCode);
		}

		if (orderedItemCode == 0) {

			double total = 0;

			System.out.println("\n----------------------------");
			System.out.println("All the orders : ");
			System.out.println("----------------------------");

			for (FoodItems f : orderlists) {

				System.out.println();
				System.out.println("Item Code  : " + f.getItemCode());
				System.out.println("Food Name  : " + f.getFoodName());
				System.out.println("Food Price : " + f.getPrice());

				total = total + f.getPrice();
			}

			System.out.println("----------------------------");
			System.out.println("The total price is : " + total);
			System.out.println("----------------------------");
			sendForTotal(total);

			orderlists.clear();

		}
	}

	public static void sendForTotal(double total) {

		finalbill.add(total);
	}

	public void viewFinalBill() {

		int count = 1;
		double dailytotal = 0;

		System.out.println("\n----------------------------");
		System.out.println("All the purchases today :");
		System.out.println("----------------------------");

		for (Double d : finalbill) {

			dailytotal = dailytotal + d;
			System.out.println("Order No. " + count + " : " + "Rs. " + d);
			count++;
		}

		System.out.println("----------------------------");
		System.out.println("Grand total = Rs. " + dailytotal);
		System.out.println("----------------------------");
	}

}
