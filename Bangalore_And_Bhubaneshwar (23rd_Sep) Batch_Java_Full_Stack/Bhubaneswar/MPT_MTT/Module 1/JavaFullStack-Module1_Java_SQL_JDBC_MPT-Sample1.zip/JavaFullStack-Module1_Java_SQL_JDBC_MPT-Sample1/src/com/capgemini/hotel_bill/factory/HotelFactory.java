package com.capgemini.hotel_bill.factory;

import com.capgemini.hotel_bill.dao.HotelDAO;
import com.capgemini.hotel_bill.dao.HotelDAOImpl;

public class HotelFactory {
	public HotelDAO getInstance()
	{
		HotelDAO hotel=new HotelDAOImpl();
		return hotel;
	}
	

}
