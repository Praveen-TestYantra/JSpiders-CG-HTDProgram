package com.capgemini.hotel_bill.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.hotel_bill.bean.HotelBean;
import com.capgemini.hotel_bill.dao.HotelDAO;
import com.capgemini.hotel_bill.factory.HotelFactory;

public class Menu {
	public static void main(String[] args) {
		HotelDAO dao = null;
		double sum = 0.0;
		Scanner sc = new Scanner(System.in);
		Validator v = new Validator();
		HotelFactory hf = new HotelFactory();
		dao = hf.getInstance();
		while (true) {
			System.out.println(
					"1.Show all food items\n2.Take order from customer\n3.Operate on food item\n4.Total bill of the day");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:

				List<HotelBean> all = dao.displayAll();
				for (HotelBean b : all) {
					System.out.print("Item code: " + b.getItem_code());
					System.out.print("\tName: " + b.getFood_name());
					System.out.println("\tPrice:" + b.getPrice());

					System.out.println("-----------------------------------------------");
				}

				break;
			case 2:
				while (true) {
					System.out.println("Enter the Item_code");
					String ch5 = sc.next();
					int ch1 = Integer.parseInt(ch5);
					if (v.idVer(ch5)) {
						if (ch1 == 0) {
							break;
						} else {

							double price = dao.takeOrder(ch1);
							sum = sum + price;
						}

					}

				}
				System.out.println("Current customer bill=" + sum);

				break;
			case 3:
				dao.foodOperation();

				break;
			case 4:
				dao.printBill();
				System.out.println("Thank you");

			}
		}
	}
}