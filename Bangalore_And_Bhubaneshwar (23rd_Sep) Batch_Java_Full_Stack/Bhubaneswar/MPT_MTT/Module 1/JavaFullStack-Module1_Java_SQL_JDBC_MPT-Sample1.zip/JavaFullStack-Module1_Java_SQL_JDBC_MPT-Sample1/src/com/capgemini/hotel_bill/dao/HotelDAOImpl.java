package com.capgemini.hotel_bill.dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotel_bill.bean.HotelBean;
import com.capgemini.hotel_bill.controller.Validator;

public class HotelDAOImpl implements HotelDAO{
	Validator v=new Validator();
	Properties prop=null;
	Scanner sc=new Scanner(System.in);
	public HotelDAOImpl() {


		try {
			FileReader reader=new FileReader("db1.properties");
			prop=new Properties();
			try {
				prop.load(reader);
			} catch (IOException e) {
				System.out.println("IO exception");
				//e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
			//e.printStackTrace();
		}
	}
	@Override
	public List<HotelBean> displayAll() {
		ArrayList<HotelBean> list=new ArrayList<HotelBean>();
		HotelBean hotel=null;
		try {
			Class.forName(prop.getProperty("driverClass"));
			String dburl=prop.getProperty("dbUrl");
			String user=prop.getProperty("user");
			String password=prop.getProperty("password");
			Connection con=DriverManager.getConnection(dburl,user,password);
			String query=prop.getProperty("query");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next())
			{
				hotel=new HotelBean();
				hotel.setItem_code(rs.getInt(1));
				hotel.setFood_name(rs.getString(2));
				hotel.setPrice(Double.parseDouble(rs.getString(3)));
				list.add(hotel);
			}
			return list ;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public double takeOrder(int c) {
		HotelBean hotel;
		double sum=0;


		try {
			Class.forName(prop.getProperty("driverClass")); 
			String dburl=prop.getProperty("dbUrl"); 
			String user=prop.getProperty("user");
			String password=prop.getProperty("password");
			Connection con=DriverManager.getConnection(dburl,user,password);
			String query="select * from hotel_bill where item_code=?"; 
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setInt(1,c);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				hotel=new HotelBean();
				hotel.setItem_code(rs.getInt(1));
				hotel.setFood_name(rs.getString(2));
				hotel.setPrice(rs.getDouble(3));
				String query1="Insert into bill1 (item_code, food_name, price) value(?,?,?)";
				PreparedStatement pstmt1=con.prepareStatement(query1);
				pstmt1.setInt(1,hotel.getItem_code());
				pstmt1.setString(2,hotel.getFood_name());
				pstmt1.setDouble(3, hotel.getPrice());
				int d=pstmt1.executeUpdate();
				if(d>0)
				{
					System.out.println("Item added");
				}
				sum=sum+hotel.getPrice();

			}

			return sum;
			/*if(count>0)
			{
				System.out.println("item added");
			}*/

		} catch (Exception e) {
			e.printStackTrace();
		}return 0.0;
	}

	@Override
	public HotelBean printBill() {
		HotelBean hotel=null;
		try {
			Class.forName(prop.getProperty("driverClass")); 

			String dburl=prop.getProperty("dbUrl"); 
			String user=prop.getProperty("user");
			String password=prop.getProperty("password");
			Connection con=DriverManager.getConnection(dburl,user,password);

			String query=prop.getProperty("query4"); 
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next())
			{
				hotel=new HotelBean();
				hotel.setPrice(Double.parseDouble(rs.getString(1)));


			}
			System.out.println("today's total bill= "+hotel.getPrice());
			return hotel;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void foodOperation() {
		System.out.println("Press A to add food item\nPress B to remove food item\nPress C to modify food item");
		String choice=sc.next();
		char ch=choice.charAt(0);
		char a='A';
		char b='B',c='C';
		if(ch==a)
		{
			System.out.println("Enter the item code");
			String d1=sc.next();
			int d=Integer.parseInt(d1);
			if(v.idVer(d1)) {
				System.out.println("Enter the food");
				String s=sc.next();
				if(v.nameVer(s)) {
					System.out.println("price:");
					String r=sc.next();
					if(v.emailVer(r)) {
						try {
							try {
								Class.forName(prop.getProperty("driverClass"));
							} catch (ClassNotFoundException e) {
								System.out.println("Driver not loaded");
							}//"com.mysql.jdbc.Driver");
							String dburl=prop.getProperty("dbUrl"); 
							String user=prop.getProperty("user");
							String password=prop.getProperty("password");
							Connection con=DriverManager.getConnection(dburl,user,password);
							String query=prop.getProperty("query5");
							PreparedStatement pstmt=con.prepareStatement(query);
							pstmt.setInt(1,d);
							pstmt.setString(2, s);
							pstmt.setString(3, r);
							int count=pstmt.executeUpdate();

							if(count>0)
							{
								System.out.println("item added");
							}

						} catch (SQLException e) {
							System.out.println("duplicate key or sql syntax error");
						}
						}else {
							System.out.println("Input should be in numbers");
						}}else {
							System.out.println("Input should be non numeric");
						}}else {
							System.out.println("Input should be in double");
						}

		}
		else if(ch==b)
		{
			try {
				System.out.println("enter food name");
				String h=sc.next();
				try {
					Class.forName(prop.getProperty("driverClass"));
				} catch (ClassNotFoundException e) {
					System.out.println("Driver not loaded");
				}//"com.mysql.jdbc.Driver");
				String dburl=prop.getProperty("dbUrl");
				String user=prop.getProperty("user");
				String password=prop.getProperty("password");
				Connection con=DriverManager.getConnection(dburl,user,password);
				String query=prop.getProperty("query6");
				PreparedStatement pstmt=con.prepareStatement(query);
				pstmt.setString(1,h);
				int count=pstmt.executeUpdate();

				if(count>0)
				{
					
					System.out.println("item removed");
				}

			} catch (SQLException e) {
				System.out.println(" sql syntax error");
			}
		}
		else if(ch==c)
		{
			try {
				System.out.println("enter Item code");
				int h=sc.nextInt();

				System.out.println("enter new food_Info");
				String b1=sc.next();
				try {
					Class.forName(prop.getProperty("driverClass"));
				} catch (ClassNotFoundException e) {
					System.out.println("Driver not loaded");
				}//"com.mysql.jdbc.Driver");
				String dburl=prop.getProperty("dbUrl");
				String user=prop.getProperty("user");
				String password=prop.getProperty("password");
				Connection con=DriverManager.getConnection(dburl,user,password);
				String query=prop.getProperty("query3");
				PreparedStatement pstmt=con.prepareStatement(query);
				pstmt.setString(1,b1);
				pstmt.setInt(2,h);
				int count=pstmt.executeUpdate();

				if(count>0)
				{
					System.out.println("item modified");
				}

			} catch (SQLException e) {
				System.out.println(" sql syntax error");
			}
			
		}		
	}


}


