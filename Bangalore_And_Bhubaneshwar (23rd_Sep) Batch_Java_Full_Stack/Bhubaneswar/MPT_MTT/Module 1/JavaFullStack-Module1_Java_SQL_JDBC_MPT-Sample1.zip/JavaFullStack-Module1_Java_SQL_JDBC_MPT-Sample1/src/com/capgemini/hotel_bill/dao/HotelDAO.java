package com.capgemini.hotel_bill.dao;

import java.util.List;

import com.capgemini.hotel_bill.bean.HotelBean;

public interface HotelDAO {
	public List<HotelBean> displayAll();
	public double takeOrder(int c);
	public HotelBean printBill();
	public void foodOperation();
	

}
