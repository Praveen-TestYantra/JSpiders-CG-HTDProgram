package com.capgemini.hotel_bill.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {
	Pattern us=null;
	Matcher mus=null;
	public boolean idVer(String id)
	{
		us=Pattern.compile("\\d+");
		mus=us.matcher(id);
		if(mus.matches()==true)
		{
			return true;
		}
			return false;
		
	}
	public boolean nameVer(String name)
	{
		us=Pattern.compile("\\w+");
		mus=us.matcher(name);
		if(mus.matches()) {
			return true;
		}
			return false;
	}
	public boolean emailVer(String price)
	{
		
		us = Pattern.compile("\\d+\\.\\d+");
		mus = us.matcher(price);
		
		if(mus.matches())
		{
			return true;
		}
		
			return false;
		
	}
	
}
