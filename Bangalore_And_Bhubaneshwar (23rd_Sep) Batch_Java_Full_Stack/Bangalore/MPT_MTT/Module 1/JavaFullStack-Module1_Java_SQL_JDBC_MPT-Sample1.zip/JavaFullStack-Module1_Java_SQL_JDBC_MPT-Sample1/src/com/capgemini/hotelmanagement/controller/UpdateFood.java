package com.capgemini.hotelmanagement.controller;

import java.util.Scanner; 
import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.factory.HotelManagementFactory;
import com.capgemini.hotelmanagement.validate.HotelFoodValidation;

public class UpdateFood {
	public static void updateItem() {
		HotelManagementController hotelController = new HotelManagementController();
		HotelFoodValidation fv = HotelManagementFactory.getValidationInstance();
		FoodItemDAO foodDAO = HotelManagementFactory.getDAOImplInstance();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				boolean result = foodDAO.updateFood(foodid1);
				if (result) {
					System.out.println("Food Item Updated Successfully.");
					hotelController.start();
				} else {
					System.out.println("Something went wrong.");
					hotelController.start();
				}
			} else {
				System.out.println("Food item is not present with this Id.");
				hotelController.start();
			}
		} else {
			System.out.println("Enter valid Food Id...");
			hotelController.start();
		}

		sc.close();
	}


}
