package com.capgemini.hotelmanagement.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.hotelmanagement.customer.OrderFood;
import com.capgemini.hotelmanagement.customer.OrderFoodController;

public class HotelManagementController {

	static double totalSaleOfOwner = 0.0;

	public static void main(String[] args) {
		HotelManagementController hotelController = new HotelManagementController();
		hotelController.start();
	}

	public void start() {
		boolean state = true;
		OrderFoodController or = new OrderFoodController();
		Scanner scanner = new Scanner(System.in);

		while (state) {
			System.out.println("***************************************");
			System.out.println("1.List food items");
			System.out.println("2.Take order from customer");
			System.out.println("3.Operate on food items");
			System.out.println("4.Generate bill");
			System.out.println("Enter your choice");

			int choice = Integer.parseInt(scanner.nextLine());

			switch (choice) {
			case 1:
				GetAllFoodInfo.getAllFood();
				break;
			case 2:
				or.takeOrder();
				break;
			case 3:
				FoodOperateController.foodOperate();
				break;
			case 4:
				ArrayList<OrderFood> alist = or.generateBillForOwner();
				Iterator<OrderFood> it = alist.iterator();
				System.out.println("************************************************************************************");
				System.out.println("ID\tName\tQuantity\tPrice");
				System.out.println("************************************************************************************");
				while (it.hasNext()) {
					OrderFood order = it.next();
					System.out.println(order.id + "\t" + order.name + "\t" + order.quantity + "\t\t" + order.price);
					totalSaleOfOwner = totalSaleOfOwner + order.price;

				}
				System.out.println("/*******/**********/**********/**********/*********");
				System.out.println("Total sale of day is : " + totalSaleOfOwner);
				System.out.println("/*******/************/************/***********/*******");

				break;

			default:
				System.out.println("Please choose correct option.");
				break;
			}

		}
		scanner.close();
	}

}
