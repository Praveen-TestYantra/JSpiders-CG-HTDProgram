package com.capgemini.hotelmanagement.validate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HotelFoodValidationImpl implements HotelFoodValidation {

	Pattern pat = null;
	Matcher mat = null;

	@Override
	public boolean idValidation(String id) {
		pat = Pattern.compile("\\d{1,10}");
		mat = pat.matcher(id);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean nameValidation(String name) {
		pat = Pattern.compile("\\w+");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean priceValidation(String price) {
		pat = Pattern.compile("\\d+\\.\\d+");
		mat = pat.matcher(price);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

}
