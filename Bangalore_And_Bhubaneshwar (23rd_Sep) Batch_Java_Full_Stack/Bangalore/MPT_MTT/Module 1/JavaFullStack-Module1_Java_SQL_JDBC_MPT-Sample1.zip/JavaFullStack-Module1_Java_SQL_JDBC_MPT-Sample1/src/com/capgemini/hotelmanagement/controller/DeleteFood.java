package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;

import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.factory.HotelManagementFactory;
import com.capgemini.hotelmanagement.validate.HotelFoodValidation;

public class DeleteFood {
	
	public static void deleteItem() {
		HotelManagementController hotelController = new HotelManagementController();
		HotelFoodValidation fv = HotelManagementFactory.getValidationInstance();
		FoodItemDAO foodDAO = HotelManagementFactory.getDAOImplInstance();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int food1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(food1)) {
				int foodid1 = Integer.parseInt(foodid);
				boolean result = foodDAO.deleteFood(foodid1);
				if (result) {
					System.out.println("Food item deleted successfully");
					hotelController.start();

				} else {
					System.out.println("Something went wrong");
					hotelController.start();
				}
			} else {
				System.out.println("Item with id is not present");
				hotelController.start();
			}
		} else {
			System.out.println("Enter valid Food id->");
			hotelController.start();
		}

		sc.close();
	}

}



