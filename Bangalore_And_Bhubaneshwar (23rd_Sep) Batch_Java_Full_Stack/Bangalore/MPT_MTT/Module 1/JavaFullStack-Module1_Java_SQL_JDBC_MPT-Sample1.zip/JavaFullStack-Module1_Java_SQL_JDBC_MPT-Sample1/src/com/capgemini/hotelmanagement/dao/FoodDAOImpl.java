package com.capgemini.hotelmanagement.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotelmanagement.bean.HotelFood;
import com.capgemini.hotelmanagement.controller.HotelManagementController;

public class FoodDAOImpl implements FoodItemDAO{
	
	HotelManagementController hotelController;
	HotelFood food;
	FileReader reader;
	Properties prop;

	public FoodDAOImpl() {
		try {
			hotelController=new HotelManagementController();
			Class.forName("com.mysql.jdbc.Driver");
			reader = new FileReader("database.properties");
			prop = new Properties();
			prop.load(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<HotelFood> getAllInfo() {
		List<HotelFood> list = new ArrayList<HotelFood>();
		String query = prop.getProperty("showQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password"));
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(query)) {
			while (rs.next()) {
				food = new HotelFood();
				food.setId(rs.getInt(1));
				food.setName(rs.getString(2));
				food.setPrice(rs.getDouble(3));
				list.add(food);
			}
			return list;
		} catch (SQLException e) {
			System.out.println("Something is wrong..");
			hotelController.start();
		}
		return null;
	}

	@Override
	public boolean insertFood(HotelFood food) {
		String query = prop.getProperty("addQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {
			pstmt.setInt(1, food.getId());
			pstmt.setString(2, food.getName());
			pstmt.setDouble(3, food.getPrice());

			int count = pstmt.executeUpdate();
			if (count > 0) {
				return true;
			}
		} catch (Exception e) {
			System.out.println("Something is wrong..");
			hotelController.start();
		}
		return false;
	}

	@Override
	public boolean getFoodItem(int foodid) {

		String query = prop.getProperty("orderQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement psmt = conn.prepareStatement(query);) {
			psmt.setInt(1, foodid);
			ResultSet rs = psmt.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			System.out.println("Something is wrong..");
			hotelController.start();
		}
		return false;

	}

	@Override
	public boolean deleteFood(int foodid) {
		String query = prop.getProperty("removeQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setInt(1, foodid);
			int count = pstmt.executeUpdate();
			if (count > 0) {
				return true;
			}
		} catch (Exception e) {
			System.out.println("Something is wrong..");
			hotelController.start();
		}
		return false;
	}

	@Override
	public boolean updateFood(int foodid) {
		Scanner sc = new Scanner(System.in);
		boolean isPresent = getFoodItem(foodid);
		if (isPresent) {
			System.out.println("What do you want to update ?\n1.Food name\n2.Price\n3.Both");
			int choice = Integer.parseInt(sc.nextLine());
			switch (choice) {
			case 1:
				System.out.println("Enter new food name");
				String name = sc.nextLine();
				return updateFood(foodid, name);

			case 2:
				System.out.println("Enter new food price");
				double price = sc.nextDouble();
				return updateFood(foodid, price);

			case 3:
				System.out.println("Enter new food name and price");
				String newName = sc.nextLine();
				double newPrice = sc.nextDouble();
				return updateFood(foodid, newName, newPrice);

			default:
				System.out.println("Please select correct option.");
				hotelController.start();
				break;
			}

		} else {
			System.out.println("No item with this ID is present.");
			hotelController.start();
		}
		
		return false;
	}

	boolean updateFood(int id, String name) {
		String query = prop.getProperty("updateNameQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, name);
			pstmt.setInt(2, id);

			int count = pstmt.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	boolean updateFood(int id, double price) {
		String query = prop.getProperty("updatePriceQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setDouble(1, price);
			pstmt.setInt(2, id);

			int count = pstmt.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	boolean updateFood(int id, String name, double price) {
		String query = prop.getProperty("updateNamePriceQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pstmt = conn.prepareStatement(query)) {

			pstmt.setString(1, name);
			pstmt.setDouble(2, price);
			pstmt.setInt(3, id);

			int count = pstmt.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public HotelFood getFoodInfo(int foodid) {
		String query = prop.getProperty("orderQuery");
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbURL"), prop.getProperty("username"),
				prop.getProperty("password")); PreparedStatement pst = conn.prepareStatement(query);) {
			pst.setInt(1, foodid);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				food = new HotelFood();
				food.setId(rs.getInt(1));
				food.setName(rs.getString(2));
				food.setPrice(rs.getDouble(3));
				return food;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

}

