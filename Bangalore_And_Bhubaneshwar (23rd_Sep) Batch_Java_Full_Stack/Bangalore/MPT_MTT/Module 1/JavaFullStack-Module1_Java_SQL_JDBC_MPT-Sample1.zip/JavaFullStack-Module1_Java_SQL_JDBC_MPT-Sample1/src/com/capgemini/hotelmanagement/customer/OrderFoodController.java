package com.capgemini.hotelmanagement.customer;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotelmanagement.bean.HotelFood;
import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.factory.HotelManagementFactory;
import com.capgemini.hotelmanagement.validate.HotelFoodValidation;

public class OrderFoodController {
	
	Scanner scanner = new Scanner(System.in);
	Properties properties = null;
	OrderFood order = null;
	static double totalBill = 0;
	static double totalOwnerSale = 0;
	ArrayList<OrderFood> custOrder = new ArrayList<OrderFood>();
	ArrayList<OrderFood> custOrder2 = new ArrayList<OrderFood>();

	public void takeOrder() {

		HotelFoodValidation fv = HotelManagementFactory.getValidationInstance();
		FoodItemDAO foodDAO = HotelManagementFactory.getDAOImplInstance();

		System.out.println("Enter Item ID ");
		String foodid = scanner.nextLine();

		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				HotelFood food = foodDAO.getFoodInfo(foodid1);
				String name = food.getName();
				double price = food.getPrice();
				System.out.println("Enter quantity ");
				int quantity = Integer.parseInt(scanner.nextLine());
				double bill = price * quantity;
				order = new OrderFood(foodid1, name, quantity, bill);
				custOrder.add(order);
				custOrder2.add(order);

				System.out.println("Do you want to order anything else ?");
				System.out.println("0.No");
				System.out.println("1.Yes");
				int choice = Integer.parseInt(scanner.nextLine());
				if (choice == 0) {
					System.out.println("**************************************************");
					System.out.println("Id\tName\tQuantity\tPrice");
					System.out.println("**************************************************");
					for (OrderFood orderFood : custOrder) {
						System.out.println(orderFood.id + "\t" + orderFood.name + "\t" + orderFood.quantity + "\t\t"
								+ orderFood.price);

						totalBill = totalBill + orderFood.price;
					}
					System.out.println("////////////////////////////////////////////////////");
					System.out.println("Your total bill is " + totalBill);
					System.out.println("////////////////////////////////////////////////////");
					totalBill = 0.0;
					custOrder.clear();

				} else {
					takeOrder();
				}

			} else {
				System.out.println("Food with this Id is not available");
			}
		} else {
			System.out.println("enter valid foodid...");
			System.exit(0);
		}

	}

	public ArrayList<OrderFood> generateBillForOwner() {
		return custOrder2;
	}

}
