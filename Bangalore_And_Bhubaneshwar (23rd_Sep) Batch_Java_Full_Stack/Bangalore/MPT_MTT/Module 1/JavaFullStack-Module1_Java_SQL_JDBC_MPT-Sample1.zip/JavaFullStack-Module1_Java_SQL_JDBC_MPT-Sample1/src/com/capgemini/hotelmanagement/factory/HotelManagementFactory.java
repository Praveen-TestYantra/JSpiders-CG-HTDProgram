package com.capgemini.hotelmanagement.factory;

import com.capgemini.hotelmanagement.customer.OrderFoodController;
import com.capgemini.hotelmanagement.dao.FoodDAOImpl;
import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.validate.HotelFoodValidation;
import com.capgemini.hotelmanagement.validate.HotelFoodValidationImpl;

public class HotelManagementFactory {
	
	private HotelManagementFactory() {

	}
	public static FoodItemDAO getDAOImplInstance() {
		FoodItemDAO dao = new FoodDAOImpl();
		return dao;
	}
	public static HotelFoodValidation getValidationInstance() {
		HotelFoodValidation validation = new HotelFoodValidationImpl();
		return validation;
	}
	
	public static OrderFoodController getOrderControllerInstance() {
		OrderFoodController orderContrller = new OrderFoodController();
		return orderContrller;
	}
	

}
