package com.capgemini.hotelmanagement.dao;

import java.util.List;

import com.capgemini.hotelmanagement.bean.HotelFood;


public interface FoodItemDAO {
	public List<HotelFood> getAllInfo();
	public boolean getFoodItem(int foodid);
	public boolean insertFood(HotelFood food);
	public boolean deleteFood(int foodid);
	public boolean updateFood(int foodid);
	public HotelFood getFoodInfo(int foodid);

}
