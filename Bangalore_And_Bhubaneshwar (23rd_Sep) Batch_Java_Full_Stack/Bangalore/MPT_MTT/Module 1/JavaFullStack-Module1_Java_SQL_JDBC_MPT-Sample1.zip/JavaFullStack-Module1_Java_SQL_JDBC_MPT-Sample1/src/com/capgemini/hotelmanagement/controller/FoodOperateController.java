package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;
 
public class FoodOperateController {
	
	public static void foodOperate() {
		int choice;
		HotelManagementController hotelController = new HotelManagementController();
		Scanner scanner = new Scanner(System.in);
		System.out.println("1.Insert new Food item.\n2.Update food item.\n" + "3.Delete food item.");
		System.out.println("Enter your choice");
		choice = Integer.parseInt(scanner.nextLine());

		switch (choice) {
		case 1:
			InsertFood.insertItem();
			hotelController.start();
			break;
		case 2:
			UpdateFood.updateItem();
			hotelController.start();
			break;
		case 3:
			DeleteFood.deleteItem();
			hotelController.start();
			break;
		default:
			System.out.println("Please choose correct option.");
			hotelController.start();
			break;
		}
		scanner.close();
	}
}

