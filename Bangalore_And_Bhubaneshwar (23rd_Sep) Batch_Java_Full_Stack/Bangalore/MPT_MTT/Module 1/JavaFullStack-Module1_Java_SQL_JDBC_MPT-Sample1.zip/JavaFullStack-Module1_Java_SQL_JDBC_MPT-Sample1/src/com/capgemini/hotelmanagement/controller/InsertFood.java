package com.capgemini.hotelmanagement.controller;

import java.util.Scanner;
import com.capgemini.hotelmanagement.bean.HotelFood;
import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.factory.HotelManagementFactory;
import com.capgemini.hotelmanagement.validate.HotelFoodValidation;

public class InsertFood {
	
	public static void insertItem() {
		HotelManagementController hotelController = new HotelManagementController();
		HotelFoodValidation fv = HotelManagementFactory.getValidationInstance();
		FoodItemDAO foodDAO = HotelManagementFactory.getDAOImplInstance();
		Scanner sc = new Scanner(System.in);
		HotelFood food = new HotelFood();

		System.out.println("Enter Food Id.");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				System.out.println("Item with same Id is already present.");
				hotelController.start();
				
			} else {
				food.setId(foodid1);
			}

		} else {
			System.out.println("Enter Valid Food Id.");
			hotelController.start();
		}

		System.out.println("Enter Food Name.");
		String foodname = sc.nextLine();
		if (fv.nameValidation(foodname)) {
			food.setName(foodname);
		} else {
			System.out.println("Enter valid Food Name.");
			hotelController.start();
		}

		System.out.println("Enter food price.");
		String price = sc.nextLine();
		if (fv.priceValidation(price)) {
			food.setPrice(Double.parseDouble(price));
		} else {
			System.out.println("Enter valid Food Price.");
			hotelController.start();
		}

		boolean b = foodDAO.insertFood(food);
		if (b) {
			System.out.println("Food Inserted.");
			hotelController.start();
		} else {
			System.out.println("Something Went Wrong.");
			hotelController.start();
		}
		sc.close();
	}

}
