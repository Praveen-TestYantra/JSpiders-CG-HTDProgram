package com.capgemini.hotelmanagement.validate;

public interface HotelFoodValidation {

	public boolean idValidation(String id);

	public boolean nameValidation(String name);

	public boolean priceValidation(String price);

}
