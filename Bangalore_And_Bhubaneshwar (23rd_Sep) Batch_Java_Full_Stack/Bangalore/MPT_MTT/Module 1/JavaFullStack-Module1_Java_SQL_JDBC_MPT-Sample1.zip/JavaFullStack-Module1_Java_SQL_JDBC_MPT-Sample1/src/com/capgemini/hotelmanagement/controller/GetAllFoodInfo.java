package com.capgemini.hotelmanagement.controller;

import java.util.List;

import com.capgemini.hotelmanagement.bean.HotelFood;
import com.capgemini.hotelmanagement.dao.FoodItemDAO;
import com.capgemini.hotelmanagement.factory.HotelManagementFactory;

public class GetAllFoodInfo {
	
	public static void getAllFood() {
		FoodItemDAO food = HotelManagementFactory.getDAOImplInstance();
		List<HotelFood> foodList = food.getAllInfo();
		for (HotelFood food2 : foodList) {
			System.out.println("ID is "+food2.getId());
		
			System.out.println("Food name is "+food2.getName());
			
			System.out.println("Food Price is "+food2.getPrice());
			System.out.println("********************************");
			System.out.println();
		}
	}
}
