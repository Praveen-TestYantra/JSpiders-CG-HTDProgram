package com.capgemini.hotel_application.controls;

import java.util.Scanner;

public class FoodOperate {
	public static void foodOperate() {
		int choice;
		HotelControl hotelController = new HotelControl();
		Scanner scanner = new Scanner(System.in);
		System.out.println("1.Insert new Food item.\n2.Update food item..\n" + "3.Delete food item.");
		System.out.println("Enter your choice");
		choice = Integer.parseInt(scanner.nextLine());

		switch (choice) {
		case 1:
			InsertItem.insertItem();
			hotelController.start();
			break;
		case 2:
			UpdateItem.updateItem();
			hotelController.start();
			break;
		case 3:
			DeleteItem.deleteItem();
			hotelController.start();
			break;
		default:
			System.out.println("Please choose correct option.");
			hotelController.start();
			break;
		}
		scanner.close();
	}
}
