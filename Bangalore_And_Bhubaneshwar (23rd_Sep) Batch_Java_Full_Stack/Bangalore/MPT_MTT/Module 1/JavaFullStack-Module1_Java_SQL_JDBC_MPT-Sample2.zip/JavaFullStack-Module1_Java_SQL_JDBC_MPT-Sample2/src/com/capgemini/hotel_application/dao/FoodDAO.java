package com.capgemini.hotel_application.dao;

import java.util.List;

import com.capgemini.hotel_application.userbean.Food;

public interface FoodDAO {
	public List<Food> getAllInfo();
	public boolean getFoodItem(int foodid);
	public boolean insertFood(Food food);
	public boolean deleteFood(int foodid);
	public boolean updateFood(int foodid);
	public Food getFoodInfo(int foodid);
}
