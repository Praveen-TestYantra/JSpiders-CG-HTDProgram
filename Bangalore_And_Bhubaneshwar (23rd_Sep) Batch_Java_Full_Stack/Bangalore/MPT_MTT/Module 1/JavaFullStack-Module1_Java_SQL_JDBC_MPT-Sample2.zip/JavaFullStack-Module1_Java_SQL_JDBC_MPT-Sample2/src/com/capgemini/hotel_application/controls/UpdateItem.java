package com.capgemini.hotel_application.controls;

import java.util.Scanner;

import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.factory.HotelAppFactory;
import com.capgemini.hotel_application.validate.FoodValidate;

public class UpdateItem {
	public static void updateItem() {
		HotelControl hotelController = new HotelControl();
		FoodValidate fv = HotelAppFactory.getValidationInstance();
		FoodDAO foodDAO = HotelAppFactory.getDAOImplInstance();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				boolean result = foodDAO.updateFood(foodid1);
				if (result) {
					System.out.println("Food item updated successfully..");
					hotelController.start();
				} else {
					System.out.println("Something went wrong.");
					hotelController.start();
				}
			} else {
				System.out.println("Food item is not present with this Id.");
				hotelController.start();
			}
		} else {
			System.out.println("enter valid foodid...");
			hotelController.start();
		}

		sc.close();
	}
}
