package com.capgemini.hotel_application.controls;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.hotel_application.customerorders.CustOrder;
import com.capgemini.hotel_application.customerorders.OrderControl;

public class HotelControl {
	static double totalSales = 0.0;

	public static void main(String[] args) {
		HotelControl hotelController = new HotelControl();
		hotelController.start();
	}

	public void start() {
		boolean state = true;
		OrderControl or = new OrderControl();
		Scanner scanner = new Scanner(System.in);

		while (state) {
			System.out.println("\n........................................");
			System.out.println("1.See all food items.\n2.Take order from customer.\n"
					+ "3.Operate on food items.\n4.Generate bill.");
			System.out.println("Enter your choice");

			int choice = Integer.parseInt(scanner.nextLine());

			switch (choice) {
			case 1:
				GetFoodItems.getAllFood();
				break;
			case 2:
				or.takeOrder();
				break;
			case 3:
				FoodOperate.foodOperate();
				break;
			case 4:
				ArrayList<CustOrder> alist = or.generateBillForOwner();
				Iterator<CustOrder> it = alist.iterator();
				System.out.println("=================================");
				System.out.println("ID\tName\tQuantity\tPrice");
				System.out.println("=================================");
				while (it.hasNext()) {
					CustOrder order = it.next();
					System.out.println(order.id + "\t" + order.name + "\t" + order.quantity + "\t\t" + order.price);
					totalSales = totalSales + order.price;

				}
				System.out.println("================================");
				System.out.println("Total bill of the day is : " + totalSales);
				System.out.println("================================");

				break;

			default:
				System.out.println("Please choose correct option.");
				break;
			}

		}
		scanner.close();
	}
}
