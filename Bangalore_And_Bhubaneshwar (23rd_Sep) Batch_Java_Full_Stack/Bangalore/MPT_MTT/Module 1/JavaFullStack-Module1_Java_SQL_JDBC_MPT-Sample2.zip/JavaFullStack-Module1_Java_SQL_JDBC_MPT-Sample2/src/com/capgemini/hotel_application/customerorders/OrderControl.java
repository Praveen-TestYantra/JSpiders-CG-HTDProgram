package com.capgemini.hotel_application.customerorders;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.factory.HotelAppFactory;
import com.capgemini.hotel_application.userbean.Food;
import com.capgemini.hotel_application.validate.FoodValidate;

public class OrderControl {
	Scanner scanner = new Scanner(System.in);
	Properties properties = null;
	CustOrder order = null;
	static double totalBill = 0;
	static double totalOwnerSale = 0;
	ArrayList<CustOrder> custOrder = new ArrayList<CustOrder>();
	ArrayList<CustOrder> custOrder2 = new ArrayList<CustOrder>();

	public void takeOrder() {

		FoodValidate fv = HotelAppFactory.getValidationInstance();
		FoodDAO foodDAO = HotelAppFactory.getDAOImplInstance();

		System.out.println("Enter Item ID ");
		String foodid = scanner.nextLine();

		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				Food food = foodDAO.getFoodInfo(foodid1);
				String name = food.getName();
				double price = food.getPrice();
				System.out.println("Enter quantity ");
				int quantity = Integer.parseInt(scanner.nextLine());
				double bill = price * quantity;
				order = new CustOrder(foodid1, name, quantity, bill);
				custOrder.add(order);
				custOrder2.add(order);

				System.out.println("Do you want to order anything else ?");
				System.out.println("0.No");
				System.out.println("1.Yes");
				int choice = Integer.parseInt(scanner.nextLine());
				if (choice == 0) {
					System.out.println("------------------------------------------");
					System.out.println("Item_Code\tFood_Name\tQuantity\tPrice");
					System.out.println("------------------------------------------");
					for (CustOrder orderFood : custOrder) {
						System.out.println(orderFood.id + "\t" + orderFood.name + "\t" + orderFood.quantity + "\t\t"
								+ orderFood.price);

						totalBill = totalBill + orderFood.price;
					}
					System.out.println("------------------------------------------");
					System.out.println("Your total bill is " + totalBill);
					System.out.println("------------------------------------------");
					totalBill = 0.0;
					custOrder.clear();

				} else {
					takeOrder();
				}

			} else {
				System.out.println("Food with this Id is not available");
			}
		} else {
			System.out.println("enter valid foodid...");
			System.exit(0);
		}

	}

	public ArrayList<CustOrder> generateBillForOwner() {
		return custOrder2;
	}
}
