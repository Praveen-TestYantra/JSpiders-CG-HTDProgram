package com.capgemini.hotel_application.controls;

import java.util.Scanner;

import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.factory.HotelAppFactory;
import com.capgemini.hotel_application.userbean.Food;
import com.capgemini.hotel_application.validate.FoodValidate;

public class InsertItem {
	public static void insertItem() {
		HotelControl hotelController = new HotelControl();
		FoodValidate fv = HotelAppFactory.getValidationInstance();
		FoodDAO foodDAO = HotelAppFactory.getDAOImplInstance();
		Scanner sc = new Scanner(System.in);
		Food food = new Food();

		System.out.println("enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				System.out.println("Item with same Id is already present..");
				hotelController.start();

			} else {
				food.setId(foodid1);
			}

		} else {
			System.out.println("enter valid foodid...");
			hotelController.start();
		}

		System.out.println("enter Food_Name...");
		String Food_Name = sc.nextLine();
		if (fv.nameValidation(Food_Name)) {
			food.setName(Food_Name);
		} else {
			System.out.println("enter valid Food_Name...");
			hotelController.start();
		}

		System.out.println("enter food price...");
		String price = sc.nextLine();
		if (fv.priceValidation(price)) {
			food.setPrice(Double.parseDouble(price));
		} else {
			System.out.println("enter valid food price...");
			hotelController.start();
		}

		boolean b = foodDAO.insertFood(food);
		if (b) {
			System.out.println("Food Inserted...");
			hotelController.start();
		} else {
			System.out.println("Something Went Wrong...");
			hotelController.start();
		}
		sc.close();
	}
}
