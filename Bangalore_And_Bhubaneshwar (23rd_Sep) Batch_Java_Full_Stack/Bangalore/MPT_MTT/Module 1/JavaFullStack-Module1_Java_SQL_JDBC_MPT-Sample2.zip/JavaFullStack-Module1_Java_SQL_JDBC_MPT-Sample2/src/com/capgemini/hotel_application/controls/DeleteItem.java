package com.capgemini.hotel_application.controls;

import java.util.Scanner;

import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.factory.HotelAppFactory;
import com.capgemini.hotel_application.validate.FoodValidate;

public class DeleteItem {
	public static void deleteItem() {
		HotelControl hotelController = new HotelControl();
		FoodValidate fv = HotelAppFactory.getValidationInstance();
		FoodDAO foodDAO = HotelAppFactory.getDAOImplInstance();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Food_Code...");
		String Food_Code = sc.nextLine();
		if (fv.idValidation(Food_Code)) {
			int food1 = Integer.parseInt(Food_Code);
			if (foodDAO.getFoodItem(food1)) {
				int Food_Code1 = Integer.parseInt(Food_Code);
				boolean result = foodDAO.deleteFood(Food_Code1);
				if (result) {
					System.out.println("Food item deleted successfully..");
					hotelController.start();

				} else {
					System.out.println("Something went wrong.");
					hotelController.start();
				}
			} else {
				System.out.println("Item with id is not present...");
				hotelController.start();
			}
		} else {
			System.out.println("enter valid Food_Code...");
			hotelController.start();
		}

		sc.close();
	}
}
