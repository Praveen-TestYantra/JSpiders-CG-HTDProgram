package com.capgemini.hotel_application.validate;

public interface FoodValidate {
	public boolean idValidation(String id);
	public boolean nameValidation(String name);
	public boolean priceValidation(String price);
}
