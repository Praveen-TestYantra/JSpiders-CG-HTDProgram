package com.capgemini.hotel_application.customerorders;

public class CustOrder {

	public int id;
	public String name;
	public int quantity;
	public double price;

	public CustOrder(int id, String name, int quantity, double price) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}

}
