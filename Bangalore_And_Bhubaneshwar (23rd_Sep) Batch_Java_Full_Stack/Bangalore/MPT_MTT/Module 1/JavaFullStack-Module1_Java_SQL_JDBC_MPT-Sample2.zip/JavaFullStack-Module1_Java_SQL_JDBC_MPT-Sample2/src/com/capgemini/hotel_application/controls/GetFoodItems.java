package com.capgemini.hotel_application.controls;

import java.util.List;

import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.factory.HotelAppFactory;
import com.capgemini.hotel_application.userbean.Food;

public class GetFoodItems {
	public static void getAllFood() {
		FoodDAO food = HotelAppFactory.getDAOImplInstance();
		List<Food> foodList = food.getAllInfo();
		for (Food food2 : foodList) {
			System.out.println(food2.getId());
			System.out.println(food2.getName());
			System.out.println(food2.getPrice());
		}
	}
}
