package com.capgemini.hotel_application.userbean;

public class Food {
	private int Item_Code;
	private String Food_Name;
	private double price;

	public int getId() {
		return Item_Code;
	}

	public void setId(int Item_Code) {
		this.Item_Code = Item_Code;
	}

	public String getName() {
		return Food_Name;
	}

	public void setName(String Food_Name) {
		this.Food_Name = Food_Name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}
