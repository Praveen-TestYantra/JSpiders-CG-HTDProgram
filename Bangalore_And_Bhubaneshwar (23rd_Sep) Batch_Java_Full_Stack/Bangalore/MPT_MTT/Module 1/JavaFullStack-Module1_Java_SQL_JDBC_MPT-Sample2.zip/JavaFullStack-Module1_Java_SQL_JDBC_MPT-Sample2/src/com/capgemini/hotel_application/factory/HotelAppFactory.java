package com.capgemini.hotel_application.factory;

import com.capgemini.hotel_application.customerorders.OrderControl;
import com.capgemini.hotel_application.dao.FoodDAO;
import com.capgemini.hotel_application.dao.FoodImplementation;
import com.capgemini.hotel_application.validate.FoodValidate;
import com.capgemini.hotel_application.validate.FoodValidateImplementation;

public class HotelAppFactory {
	private HotelAppFactory() {

	}
	public static FoodDAO getDAOImplInstance() {
		FoodDAO dao = new FoodImplementation();
		return dao;
	}
	public static FoodValidate getValidationInstance() {
		FoodValidate validation = new FoodValidateImplementation();
		return validation;
	}
	
	public static OrderControl getOrderControllerInstance() {
		OrderControl orderContrller = new OrderControl();
		return orderContrller;
	}
}
