package com.capgemini.hotel.controller;

import java.util.Scanner;

import com.capgemini.hotel.dao.FoodDAO;
import com.capgemini.hotel.dto.FoodBean;
import com.capgemini.hotel.factory.HotelFactory;
import com.capgemini.hotel.main.HotelApp;
import com.capgemini.hotel.validation.FoodValidation;

public class InsertFoodItem {

	public static void insertItem() {
		HotelApp hotelController = new HotelApp();
		FoodValidation fv = HotelFactory.getValidationInstance();
		FoodDAO foodDAO = HotelFactory.getDAOImplInstance();
		Scanner sc = new Scanner(System.in);
		FoodBean food = new FoodBean();

		System.out.println("enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				System.out.println("Item with same Id is already present..");
				hotelController.start();
				
			} else {
				food.setItemCode(foodid1);
			}

		} else {
			System.out.println("enter valid foodid...");
			hotelController.start();
		}

		System.out.println("enter foodname...");
		String foodname = sc.nextLine();
		if (fv.nameValidation(foodname)) {
			food.setItemName(foodname);
		} else {
			System.out.println("enter valid foodname...");
			hotelController.start();
		}

		System.out.println("enter food price...");
		String price = sc.nextLine();
		if (fv.priceValidation(price)) {
			food.setItemPrice(Double.parseDouble(price));
		} else {
			System.out.println("enter valid food price...");
			hotelController.start();
		}

		boolean b = foodDAO.insertFood(food);
		if (b) {
			System.out.println("Food Inserted...");
			hotelController.start();
		} else {
			System.out.println("Something Went Wrong...");
			hotelController.start();
		}
		sc.close();
	}

}
