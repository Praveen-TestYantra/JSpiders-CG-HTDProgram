package com.capgemini.hotel.controller;

import java.util.List;

import com.capgemini.hotel.dao.FoodDAO;
import com.capgemini.hotel.dto.FoodBean;
import com.capgemini.hotel.factory.HotelFactory;

public class GetAllFoodItems {

	public static void getAllFood() {
		System.out.println("Id\tFood name\tPrice");
		System.out.println("------------------------------------");
		FoodDAO food = HotelFactory.getDAOImplInstance();
		List<FoodBean> foodList = food.getAllInfo();
		for (FoodBean food2 : foodList) {
			System.out.println(food2.getItemCode()+"\t"+food2.getItemName()+"\t\t"+food2.getItemPrice());

		}
	}

}
