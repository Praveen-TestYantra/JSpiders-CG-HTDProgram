package com.capgemini.hotel.factory;

import com.capgemini.hotel.customer.OrderController;
import com.capgemini.hotel.dao.FoodDAO;
import com.capgemini.hotel.dao.FoodDAOJDBCImpl;
import com.capgemini.hotel.validation.FoodValidation;
import com.capgemini.hotel.validation.FoodValidationImpl;

public class HotelFactory {
	
	private HotelFactory() {

	}
	public static FoodDAO getDAOImplInstance() {
		FoodDAO dao = new FoodDAOJDBCImpl();
		return dao;
	}
	public static FoodValidation getValidationInstance() {
		FoodValidation validation = new FoodValidationImpl();
		return validation;
	}
	
	public static OrderController getOrderControllerInstance() {
		OrderController orderContrller = new OrderController();
		return orderContrller;
	}
}
