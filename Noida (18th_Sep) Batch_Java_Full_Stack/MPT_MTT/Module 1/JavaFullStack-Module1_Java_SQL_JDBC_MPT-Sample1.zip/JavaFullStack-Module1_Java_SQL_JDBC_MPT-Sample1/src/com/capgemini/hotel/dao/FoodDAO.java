package com.capgemini.hotel.dao;

import java.util.List;

import com.capgemini.hotel.dto.FoodBean;


public interface FoodDAO {
	public List<FoodBean> getAllInfo();
	public boolean getFoodItem(int foodid);
	public boolean insertFood(FoodBean food);
	public boolean deleteFood(int foodid);
	public boolean updateFood(int foodid);
	public FoodBean getFoodInfo(int foodid);
}
