package com.capgemini.hotel.controller;

import java.util.Scanner;
import com.capgemini.hotel.dao.FoodDAO;
import com.capgemini.hotel.factory.HotelFactory;
import com.capgemini.hotel.main.HotelApp;
import com.capgemini.hotel.validation.FoodValidation;

public class UpdateFoodItem {

	public static void updateItem() {
		HotelApp hotelController = new HotelApp();
		FoodValidation fv = HotelFactory.getValidationInstance();
		FoodDAO foodDAO = HotelFactory.getDAOImplInstance();

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter foodid...");
		String foodid = sc.nextLine();
		if (fv.idValidation(foodid)) {
			int foodid1 = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(foodid1)) {
				boolean result = foodDAO.updateFood(foodid1);
				if (result) {
					System.out.println("Food item updated successfully..");
					hotelController.start();
				} else {
					System.out.println("Something went wrong.");
					hotelController.start();
				}
			} else {
				System.out.println("Food item is not present with this Id.");
				hotelController.start();
			}
		} else {
			System.out.println("enter valid foodid...");
			hotelController.start();
		}

		sc.close();
	}

}
