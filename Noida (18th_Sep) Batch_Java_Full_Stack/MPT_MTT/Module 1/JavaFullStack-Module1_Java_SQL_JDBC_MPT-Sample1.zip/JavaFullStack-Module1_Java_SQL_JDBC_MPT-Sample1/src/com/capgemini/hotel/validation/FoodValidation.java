package com.capgemini.hotel.validation;

public interface FoodValidation {
	public boolean idValidation(String id);
	public boolean nameValidation(String name);
	public boolean priceValidation(String price);
	
}
