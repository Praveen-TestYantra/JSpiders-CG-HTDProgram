package com.capgemini.hotel.controller;

import java.util.Scanner;

import com.capgemini.hotel.main.HotelApp;

public class FoodOperationController {

	public static void foodOperate() {
		int choice;
		HotelApp hotelController = new HotelApp();
		Scanner scanner = new Scanner(System.in);
		System.out.println("1.Insert new Food item.\n2.Update food item..\n" + "3.Delete food item.");
		System.out.println("Enter your choice");
		choice = Integer.parseInt(scanner.nextLine());

		switch (choice) {
		case 1:
			InsertFoodItem.insertItem();
			hotelController.start();
			break;
		case 2:
			UpdateFoodItem.updateItem();
			hotelController.start();
			break;
		case 3:
			DeleteFoodItem.deleteItem();
			hotelController.start();
			break;
		default:
			System.out.println("Please choose correct option.");
			hotelController.start();
			break;
		}
		scanner.close();
	}
}
