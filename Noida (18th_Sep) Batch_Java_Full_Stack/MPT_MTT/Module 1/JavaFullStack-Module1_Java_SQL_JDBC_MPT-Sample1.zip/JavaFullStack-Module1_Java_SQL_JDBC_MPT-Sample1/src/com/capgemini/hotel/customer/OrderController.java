package com.capgemini.hotel.customer;

import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotel.dao.FoodDAO;
import com.capgemini.hotel.dto.FoodBean;
import com.capgemini.hotel.factory.HotelFactory;
import com.capgemini.hotel.validation.FoodValidation;

public class OrderController {
	Scanner scanner = new Scanner(System.in);
	Properties properties = null;
	static double orderBill = 0;
	static double totalOwnerSale = 0;
	
	public double takeOrder() {

		FoodValidation fv = HotelFactory.getValidationInstance();
		FoodDAO foodDAO = HotelFactory.getDAOImplInstance();

		System.out.println("Enter Item ID ");
		String foodid = scanner.nextLine();

		if (fv.idValidation(foodid)) {
			int itemCode = Integer.parseInt(foodid);
			if (foodDAO.getFoodItem(itemCode)) {
				FoodBean food = foodDAO.getFoodInfo(itemCode);
				String name = food.getItemName();
				double price = food.getItemPrice();
				System.out.println("Enter quantity ");
				int quantity = Integer.parseInt(scanner.nextLine());
				double bill = price * quantity;

				System.out.println("Do you want to order anything else ?");
				System.out.println("0.No");
				System.out.println("1.Yes");
				int choice = Integer.parseInt(scanner.nextLine());
				if (choice == 0) {
					
					System.out.println("Your total bill is " + orderBill);
					double ordertotalBill = orderBill;
					orderBill = 0.0;
					return ordertotalBill;
				} else {
					System.out.println("Id\tName\tQuantity\tPrice");
					System.out.println(itemCode+"\t"+name+"\t"+quantity+"\t"+price);
					orderBill += bill;
					takeOrder();
				}

			} else {
				System.out.println("Food with this Id is not available");
			}
		} else {
			System.out.println("enter valid foodid...");
			System.exit(0);
		}
		return 0;

	}

}
