package com.capgemini.hotel.main;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.capgemini.hotel.controller.FoodOperationController;
import com.capgemini.hotel.controller.GetAllFoodItems;
import com.capgemini.hotel.customer.Order;
import com.capgemini.hotel.customer.OrderController;

public class HotelApp {
	private static double totalBill = 0.0;

	public static void main(String[] args) {
		HotelApp hotelController = new HotelApp();
		hotelController.start();
	}

	public void start() {
		OrderController or = new OrderController();
		Scanner scanner = new Scanner(System.in);

		while (true) {
			System.out.println("1.Show all food items.\n2.Take order.\n"
					+ "3.Operate on food.\n4.Generate bill for the day.");
			System.out.println("Enter your choice");

			int choice = Integer.parseInt(scanner.nextLine());

			switch (choice) {
			case 1:
				GetAllFoodItems.getAllFood();
				break;
			case 2:
				or.takeOrder();
				break;
			case 3:
				FoodOperationController.foodOperate();
				break;
			case 4:
				ArrayList<Order> alist = or.generateBillForOwner();
				Iterator<Order> it = alist.iterator();
				System.out.println("Item Code\tItem Name\tQuantity\tPrice");
				while (it.hasNext()) {
					Order order = it.next();
					System.out.println(order.id + "\t" + order.name + "\t" + order.quantity + "\t\t" + order.price);
					totalBill = totalBill + order.price;

				}
				System.out.println("Total bill for the day is : " + totalBill);
				break;

			default:
				System.out.println("Please choose correct option.");
				break;
			}

		}
	}

}
