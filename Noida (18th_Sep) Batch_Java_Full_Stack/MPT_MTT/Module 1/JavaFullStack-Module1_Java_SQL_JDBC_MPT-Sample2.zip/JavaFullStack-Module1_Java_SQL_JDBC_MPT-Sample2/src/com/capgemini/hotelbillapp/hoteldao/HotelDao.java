package com.capgemini.hotelbillapp.hoteldao;

import java.util.List;

import com.capgemini.hotelbillapp.hotelbean.HotelBean;

public interface HotelDao {
	public List<HotelBean> getAllInfo();
}
