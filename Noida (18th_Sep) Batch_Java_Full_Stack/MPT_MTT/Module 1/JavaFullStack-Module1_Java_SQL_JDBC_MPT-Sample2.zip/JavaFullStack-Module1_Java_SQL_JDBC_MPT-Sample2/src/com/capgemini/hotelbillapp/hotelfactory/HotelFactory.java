package com.capgemini.hotelbillapp.hotelfactory;

import com.capgemini.hotelbillapp.hoteldao.HotelDao;
import com.capgemini.hotelbillapp.hoteldao.HotelDaoImpl;

public class HotelFactory {
	public HotelFactory() {

	}

	public static HotelDao getInstance() {

		HotelDao dao = new HotelDaoImpl();
		return dao;
	}

}
