package com.capgemini.hotelbillapp.hotelbean;

public class HotelBean {
	private int itemCode;
	private String foodName;
	private double price;
	public int getItemCode() {
		return itemCode;
	}
	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "HotelBean [itemCode=" + itemCode + ", foodName=" + foodName + ", price=" + price + "]";
	}

}
