package com.capgemini.hotelbillapp.controller;

import java.util.List;

import com.capgemini.hotelbillapp.hotelbean.HotelBean;
import com.capgemini.hotelbillapp.hoteldao.HotelDao;
import com.capgemini.hotelbillapp.hotelfactory.HotelFactory;

public class HenceforthApp {
	public static void main(String[] args) {
		HotelDao dao = HotelFactory.getInstance();
		List<HotelBean> userList = dao.getAllInfo();

		if (userList != null) {
			for (HotelBean user : userList) {
				System.out.println(user);
			}
		} else {
			System.out.println("something went wrong");

		}

	}
}
