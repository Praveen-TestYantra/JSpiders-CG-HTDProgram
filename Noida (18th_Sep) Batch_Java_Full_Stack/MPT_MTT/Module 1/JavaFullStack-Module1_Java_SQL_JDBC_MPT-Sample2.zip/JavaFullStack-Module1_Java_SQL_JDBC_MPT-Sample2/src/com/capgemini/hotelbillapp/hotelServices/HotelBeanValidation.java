package com.capgemini.hotelbillapp.hotelServices;

public interface HotelBeanValidation {

	public boolean itemCodevalidation(String itemCode);
	public boolean foodNameValidation(String foodName);
	public boolean priceValidation(String price);
}


