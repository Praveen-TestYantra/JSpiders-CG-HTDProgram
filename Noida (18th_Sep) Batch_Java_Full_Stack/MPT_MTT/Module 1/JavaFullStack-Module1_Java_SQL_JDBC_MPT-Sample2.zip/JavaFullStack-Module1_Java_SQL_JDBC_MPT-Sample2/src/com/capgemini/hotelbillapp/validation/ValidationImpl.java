package com.capgemini.hotelbillapp.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.hotelbillapp.hotelServices.HotelBeanValidation;

public class ValidationImpl implements HotelBeanValidation{
	Pattern pat=null;
	Matcher mat=null;

	@Override
	public boolean itemCodevalidation(String itemCode) {
		pat = Pattern.compile("\\d+");
		mat = pat.matcher("itemCode");
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean foodNameValidation(String foodName) {
		pat = Pattern.compile("\\w+\\s\\w+");
		mat = pat.matcher(foodName);
		if(mat.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean priceValidation(String price) {
		pat = Pattern.compile("\\d+");
		mat = pat.matcher("price");
		if(mat.matches()) {
			return true;
		}
		return false;
	}
}
