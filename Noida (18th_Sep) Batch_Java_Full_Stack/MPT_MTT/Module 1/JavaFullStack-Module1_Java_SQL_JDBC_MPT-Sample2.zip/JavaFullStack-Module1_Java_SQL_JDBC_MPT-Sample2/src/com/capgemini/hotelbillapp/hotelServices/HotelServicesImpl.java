package com.capgemini.hotelbillapp.hotelServices;

import java.util.List;

import com.capgemini.hotelbillapp.hotelbean.HotelBean;

public class HotelServicesImpl implements HotelServices{

	@Override
	public List<HotelBean> getAllInfo() {
		return null;
	}

}
