package com.capgemini.hotelbillapp.hoteldao;

import java.io.FileReader;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import com.capgemini.hotelbillapp.hotelbean.HotelBean;


public class HotelDaoImpl implements HotelDao {
	Properties prop = null;
	FileReader reader = null;
	HotelBean user;

	public HotelDaoImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);

		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public List<HotelBean> getAllInfo() {
		Scanner sc = new Scanner(System.in);
		List<HotelBean> userList = new ArrayList<HotelBean>();
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dbUrl"), prop.getProperty("user"),
				prop.getProperty("password")); Statement pstmt = conn.createStatement();) {
			{
				int i = 1;
				do {
					System.out.println("Select any of the options");
					System.out.println(" 1- To view the FoodItems-");
					System.out.println(" 2-To Take order From Customer-");
					System.out.println(" 3- To Perform operation on Fooditems-");
					System.out.println(" 4- TO Print total bill-");

					int a = sc.nextInt();
					if (a == 1) {

						CallableStatement cs = conn.prepareCall(prop.getProperty("query"));
						boolean b = cs.execute();

						if (b)

						{
							ResultSet rs = cs.getResultSet();
							while (rs.next()) {
								System.out.println("Item_Code-->" + rs.getInt(1));
								System.out.println("Food_Name-->" + rs.getString(2));
								System.out.println("Price-->" + rs.getDouble(3));
								System.out.println("............................................");
							}
						} else {
							int count = cs.getUpdateCount();
							if (count > 0) {
								System.out.println("Updated");
							}
						}
					}


					else if (a == 2) {
						int y = 1;
						do {
							PreparedStatement pst = conn.prepareStatement(prop.getProperty("query2"));
							System.out.println("Enter Item code-");
							pst.setInt(1, sc.nextInt());
							System.out.println("Enter Price-");

							pst.setDouble(2, Double.parseDouble(sc.next()));

							int res = pst.executeUpdate();
							if (res > 0) {

								System.out.println("Order has been received");

							}
							System.out.println("Would you like to order something else: Y/N");
							String st = sc.next();
							if (st.equals("Y")) {
								y++;
							} else {
								y = 0;
							}

						} while (y != 0);

					}

					else if (a == 3) {
						System.out.println("Press A to add item");
						System.out.println("Press B to modify item");
						System.out.println("Press C to delete item");
						String ch = sc.next();
						if (ch.equals("A")) {

							PreparedStatement pst = conn.prepareStatement(prop.getProperty("query2"));
							System.out.println("Enter item code-");

							pst.setInt(1, Integer.parseInt(sc.next()));

							System.out.println("Enter price-");

							pst.setDouble(2, Double.parseDouble(sc.next()));

							int res = pst.executeUpdate();
							if (res > 0) {
								System.out.println("Item has been added");
							}
						} else if (ch.equals("B")) {

							PreparedStatement pst = conn.prepareStatement(prop.getProperty("query3"));
							System.out.println("Enter item code-");

							pst.setInt(1, sc.nextInt());

							System.out.println("Enter price-");

							pst.setDouble(2, Double.parseDouble(sc.next()));

							int res = pst.executeUpdate();
							if (res > 0) {
								System.out.println("Order modified");
							}
						}

						else if (ch.equals("C")) {

							PreparedStatement pst = conn.prepareStatement(prop.getProperty("query4"));
							System.out.println("Enter item code-");

							pst.setInt(1, Integer.parseInt(sc.next()));
							int res = pst.executeUpdate();
							if (res > 0) {
								System.out.println("Item has been deleted");
							}
						} else {
							System.out.println("you have entered wrong option");
						}
					}


					else if (a == 4) {
						Statement st = conn.createStatement();
						ResultSet rt = st.executeQuery(prop.getProperty("query5"));
						while (rt.next()) {
							System.out.println("Total bill is: " + rt.getDouble(3));
						}
					} else {
						System.out.println("Enter the correct Option");
					}


					System.out.println("Do you want to see the options:Press Y/N");
					String st = sc.next();
					if (st.equals("Y")) {
						i++;
					} else {
						i = 0;
					}
				} while (i!= 0);

				return userList;

			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

}