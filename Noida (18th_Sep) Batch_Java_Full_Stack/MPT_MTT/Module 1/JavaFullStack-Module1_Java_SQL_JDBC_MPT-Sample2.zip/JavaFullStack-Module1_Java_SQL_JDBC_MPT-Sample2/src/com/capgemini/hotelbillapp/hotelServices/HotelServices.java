package com.capgemini.hotelbillapp.hotelServices;

import java.util.List;

import com.capgemini.hotelbillapp.hotelbean.HotelBean;

public interface HotelServices {
	
	public List<HotelBean> getAllInfo();
	

}
